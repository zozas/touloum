<?php

ini_set('display_errors', 'On');
error_reporting(E_ALL | E_STRICT);

	/* 01 - Login
	 * 02 - Logout
	 * 03 - Remind password (email)
	 * 04 - Change password
	 * 05 - Add new user
	 * 06 - Approve poem (poem id)
	 * 07 - Disaprove poem (poem id)
	 * 08 - Delete poem (poem data)
	 * 09 - Delete comment (comment data)
	 * 10 - Create comment (comment data)
	 * 11 - Create report (report data)
	 * 12 - Search string (query)
	 * 13 - Clean log file
	 */
	 
class log {
	function update($action, $data, $user, $ip) {
		Global $config;
		Global $database;	
		$sql = "INSERT INTO `log` ( `id` , `user` , `action` , `data` , `date`, `ip` ) VALUES (NULL , '".$user."', '".$action."', '".$data."', NOW(), '".$ip."' );";
		$result = $database->setquery($sql);
	}
	function get() {
		Global $config;
		Global $database;	
		$sql = "SELECT * FROM `log` ORDER BY `date` DESC LIMIT ".$config->get('APPLICATION', 'LOG_SIZE').";";
		$result = $database->getquery($sql);
		return $result;
	}
	function backup() {
		Global $config;
		Global $database;	
		$sql = "SELECT * FROM `log` ORDER BY `date`;";
		$result = $database->getquery($sql);
		return $result;
	}
	function count() {
		Global $config;
		Global $database;	
		$sql = "SELECT COUNT(*) FROM `log`;";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	function clean() {
		Global $config;
		Global $database;
		$sql = "DELETE FROM `log` WHERE `id` NOT IN (SELECT `id` FROM ( SELECT `id` FROM `log` ORDER BY `id` DESC LIMIT ".$config->get('APPLICATION', 'LOG_SIZE')." ) foo );";
		$result = $database->setquery($sql);
	}
}
class statistics {
	public function latest_poems() {
		Global $config;
		Global $database;		
		$sql = "SELECT * FROM `poems` WHERE `status` = 1 ORDER BY `date` DESC LIMIT 5;";
		$result = $database->getquery($sql);
		return $result;
	}
	public function top_poems() {
		Global $config;
		Global $database;		
		$sql = "SELECT * FROM `poems` WHERE `status` = 1 ORDER BY `popularity` DESC LIMIT 5;";
		$result = $database->getquery($sql);
		return $result;
	}
	public function latest_comments() {
		Global $config;
		Global $database;		
		$sql = "SELECT * FROM `comments` ORDER BY `date` DESC LIMIT 5;";
		$result = $database->getquery($sql);
		return $result;
	}
	public function top_poem_comments() {
		Global $config;
		Global $database;
		$sql_count = "SELECT DISTINCT `poems`.`id`, (SELECT COUNT(*) FROM `comments` WHERE `poem` = `poems`.`id`) AS `memberCount` FROM `poems` ORDER BY `memberCount` DESC LIMIT 5;";
		$result_count = $database->getquery($sql_count);
		return $result_count;
	}
	public function top_poem_users() {
		Global $config;
		Global $database;
		$sql_count = "SELECT DISTINCT `users`.`id`, (SELECT COUNT(*) FROM `poems` WHERE `user` = `users`.`id` AND `status` = 1) AS `memberCount` FROM `users` ORDER BY `memberCount` DESC LIMIT 5;";
		$result_count = $database->getquery($sql_count);
		return $result_count;
	}
	public function top_poem_users_all() {
		Global $config;
		Global $database;
		$sql_count = "SELECT DISTINCT `users`.`id`, (SELECT COUNT(*) FROM `poems` WHERE `user` = `users`.`id` AND `status` = 1) AS `memberCount` FROM `users` ORDER BY `memberCount` DESC;";
		$result_count = $database->getquery($sql_count);
		return $result_count;
	}
	public function user_comments($user_id) {
		Global $config;
		Global $database;
		$sql_count = "SELECT DISTINCT `comments`.`id`, (SELECT COUNT(*) FROM `poems` WHERE `poems`.`id` = `comments`.`poem` AND `user` = '".$user_id."') AS `memberCount` FROM `comments`;";
		$result_count = $database->getquery($sql_count);
		$total = 0;
		for($i = 0; $i < sizeof($result_count); $i ++)
			$total = $total + $result_count[$i]['memberCount'];
		return $total;
	}
	public function user_reports($user_id) {
		Global $config;
		Global $database;
		$sql_count = "SELECT DISTINCT `reports`.`id`, (SELECT COUNT(*) FROM `poems` WHERE `poems`.`id` = `reports`.`poem` AND `user` = '".$user_id."') AS `memberCount` FROM `reports`;";
		$result_count = $database->getquery($sql_count);
		$total = 0;
		for($i = 0; $i < sizeof($result_count); $i ++)
			$total = $total + $result_count[$i]['memberCount'];
		return $total;
	}
	public function user_likes($user_id) {
		Global $config;
		Global $database;
		$sql_count = "SELECT SUM(`poems`.`popularity`) FROM `poems` WHERE `poems`.`user` = '".$user_id."';";
		$result_count = $database->getquery($sql_count);
		if ($result_count[0][0]=='')
			$result_count[0][0] = 0;
		return $result_count[0][0];
	}
}
class reports {
	public function create($poem_id, $annotate_data, $current_user) {
		Global $config;
		Global $database;
		if($annotate_data == '')
			$annotate_data = '?';
		$sql = "INSERT INTO `reports` (`id`, `poem`, `user`, `data`, `date`, `pending`) VALUES (NULL, '".$poem_id."', '".$current_user."', '".str_replace(array("'", "\"", "&quot;"), "", htmlspecialchars($annotate_data))."', NOW(), '0');";
		$result = $database->setquery($sql);
	}
	public function count_pending() {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `reports` WHERE `pending`='0';";
		$result = $database->getquery($sql);
		return $result[0][0];
	}	
	public function count_completed() {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `reports` WHERE `pending`='1';";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function get($search_report) {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `reports` WHERE `id` = '".$search_report."';";
		$result = $database->getquery($sql);
		return $result[0];
	}
	public function get_pending() {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `reports` WHERE `pending`='0';";
		$result = $database->getquery($sql);
		return $result;
	}
	public function get_completed() {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `reports` WHERE `pending`='1';";
		$result = $database->getquery($sql);
		return $result;
	}
	public function delete($search_report) {
		Global $config;
		Global $database;
		$sql = "DELETE FROM `reports` WHERE `id` = '".$search_report."';";
		$result = $database->setquery($sql);
	}
	public function conclude($search_report) {
		Global $config;
		Global $database;
		$sql = "UPDATE `reports` SET `pending` = 1 WHERE `id` = '".$search_report."';";
		$result = $database->setquery($sql);
	}
}
class comment {
	public function count($search_poem='') {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `comments` WHERE `poem`='".$search_poem."';";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function count_all() {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `comments`;";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function search($search_poem='') {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `comments` WHERE `poem`='".$search_poem."' ORDER BY `date` DESC ;";
		$result = $database->getquery($sql);
		return $result;
	}
	public function get($search_comment='') {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `comments` WHERE `id`='".$search_comment."';";
		$result = $database->getquery($sql);
		return $result[0];
	}
	public function delete($search_comment) {
		Global $config;
		Global $database;
		$sql = "DELETE FROM `comments` WHERE `id` = '".$search_comment."';";
		$result = $database->setquery($sql);
	}
	public function create($poem_id, $annotate_data, $current_user) {
		Global $config;
		Global $database;
		if($annotate_data == '')
			$annotate_data = '?';
		$sql = "INSERT INTO `comments` (`id`, `poem`, `user`, `data`, `date`) VALUES (NULL, '".$poem_id."', '".$current_user."', '".str_replace(array("'", "\"", "&quot;"), "", htmlspecialchars($annotate_data))."', NOW());";
		$result = $database->setquery($sql);
	}
}
class poem {
	public function create($poem_data, $poem_category, $poem_origin, $user, $poem_name) {
		Global $config;
		Global $database;
		if($poem_data == '')
			$poem_data = '?';
		$sql = "INSERT INTO `poems` (`id`, `user`, `owner`, `category`, `data`, `name`, `date`, `popularity`, `status`) VALUES (NULL, '".$user."', '".$poem_origin."', '".$poem_category."', '".str_replace(array("'", "\"", "&quot;"), "", htmlspecialchars($poem_data))."', '".str_replace(array("'", "\"", "&quot;"), "", htmlspecialchars($poem_name))."', NOW(), '0', '0');";
		$result = $database->setquery($sql);
	}
	public function update($poem_id, $poem_data, $poem_category, $poem_origin, $user, $poem_name) {
		Global $config;
		Global $database;
		$sql = "UPDATE `poems` SET `owner` = '".$poem_origin."', `category` = '".$poem_category."', `data` = '".str_replace(array("'", "\"", "&quot;"), "", htmlspecialchars($poem_data))."', `name` = '".str_replace(array("'", "\"", "&quot;"), "", htmlspecialchars($poem_name))."', `date` = NOW(), `status` = 0 WHERE `id` = '".$poem_id."';";
		$result = $database->setquery($sql);
	}
	public function delete($poem_id) {
		Global $config;
		Global $database;
		$sql = "DELETE FROM `poems` WHERE `id` = '".$poem_id."';";
		$result = $database->setquery($sql);
		$sql = "DELETE FROM `comments` WHERE `poem` = '".$poem_id."';";
		$result = $database->setquery($sql);
		$sql = "DELETE FROM `reports` WHERE `poem` = '".$poem_id."';";
		$result = $database->setquery($sql);
	}
	public function count($search_user='') {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `poems` WHERE `user`='".$search_user."';";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function count_pending($search_user='') {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `poems` WHERE `status` = 0 AND `user`='".$search_user."';";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function count_drafts() {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `poems` WHERE `status` = 0;";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function count_accepted() {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `poems` WHERE `status` = 1;";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function count_popularity() {
		Global $config;
		Global $database;
		$sql = "SELECT SUM(`popularity`) FROM `poems`;";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function like($poem_id) {
		Global $config;
		Global $database;
		$sql = "UPDATE `poems` SET `popularity` = `popularity` + 1 WHERE `id` = ".$poem_id.";";
		$result = $database->setquery($sql);
	}
	public function approve($poem_id) {
		Global $config;
		Global $database;
		$sql = "UPDATE `poems` SET `status` = 1 WHERE `id` = ".$poem_id.";";
		$result = $database->setquery($sql);
	}
	public function disapprove($poem_id) {
		Global $config;
		Global $database;
		$sql = "UPDATE `poems` SET `status` = 0 WHERE `id` = ".$poem_id.";";
		$result = $database->setquery($sql);
	}
	public function get($poem_id) {
		Global $config;
		Global $database;		
		$sql = "SELECT * FROM `poems` WHERE `id` = ".$poem_id.";";
		$result = $database->getquery($sql);
		return $result[0];
	}
	public function search($search_string='', $search_user='', $search_category='', $search_owner='', $status='', $page='') {
		Global $config;
		Global $database;
		$sql = "";
		if ($search_string!='' || $search_user!='' || $search_category!='' || $search_owner!='' || $status!='')
			$sql = $sql." WHERE ";
		if ($search_string!='')
			$sql = $sql." (`data` LIKE '%".$search_string."%' OR `name` LIKE '%".$search_string."%') ";
		if ($search_user!='')
			if ($search_string!='')
				$sql = $sql." AND `user` = '".$search_user."' ";
			else
				$sql = $sql." `user` = '".$search_user."' ";
		if ($search_owner!='')
			if ($search_string!='' || $search_user!='')
				$sql = $sql." AND `owner` = '".$search_owner."' ";
			else
				$sql = $sql." `owner` = '".$search_owner."' ";
		if ($search_category!='')
			if ($search_string!='' || $search_user!='' || $search_owner!='')
				$sql = $sql." AND `category` = '".$search_category."' ";
			else
				$sql = $sql." `category` = '".$search_category."' ";
		if ($status!='')
			if ($search_string!='' || $search_user!='' || $search_category!='' || $search_owner!='')
				$sql = $sql." AND `status` = '".$status."' ";
			else
				$sql = $sql." `status` = '".$status."' ";
		if ($page=='')
			$page = 0;
		$sql_count = "SELECT COUNT(*) FROM `poems`".$sql.";";
		$sql = "SELECT * FROM `poems`".$sql." ORDER BY `date` DESC ";		
		$result_count = $database->getquery($sql_count);
		$sql = $sql." LIMIT ".$config->get('POEMS', 'SEARCH_PAGINATION')." OFFSET ".($page*$config->get('POEMS', 'SEARCH_PAGINATION')).";";
		$result = $database->getquery($sql);
		$result['count'] = $result_count[0][0];
		return $result;
	}
}
class session {
	public function __construct() {
		if(!isset($_SESSION)) {
			session_start();
			return TRUE;
		} else {
			return FALSE;
		}
	}
	public function erase_session() {
		setcookie(session_name(), NULL, 0, "/");
		session_destroy();
		session_unset();
	}
	public function set($key, $value) {
		return $_SESSION[$key] = $value;
	}
	public function exist($key) {
		if(isset($_SESSION[$key])) {
			return TRUE;
		}
		return FALSE;
	}
	public function delete($key) {
		unset($_SESSION[$key]);
	}
	public function get($key) {
		if(!isset($_SESSION[$key])) {
			return FALSE;
		}
		return $_SESSION[$key];
	}
}
class ini {
	private $file = NULL;
	private $data = array();
	public function open($file) {
		$this->file = $file;
		if($file != '') {
			if(is_readable($file)) {
				$this->file = $file;
				return(TRUE);
			} else {
				return(FALSE);
			}
		} else {
			return(FALSE);
		}
	}
	public function read() {
		$this->data = parse_ini_file(realpath($this->file), TRUE);
		if ($this->data == FALSE) {
			return(FALSE);
		} else {
			return(TRUE);
		}
	}
	public function write() {
		$content = NULL;
		foreach ($this->data as $section => $data) {
			$content = $content.'['.$section.']'.PHP_EOL;
			foreach ($data as $key => $val) {
				if (is_array($val)) {
					foreach ($val as $v) {
						$content = $content.$key.'[] = '.(is_numeric($v) ? $v : '"'.$v.'"').PHP_EOL;
					}
				} elseif (empty($val)) {
					$content = $content.$key.' = '.PHP_EOL;
				} else {
					$content = $content.$key.' = '.(is_numeric($val) ? $val : '"'.$val.'"').PHP_EOL;
				}
			}
			$content = $content.PHP_EOL;
		}
		return (($handle = fopen($this->file, 'w')) && fwrite($handle, ";<?php".PHP_EOL.";die();".PHP_EOL.";/*".PHP_EOL.trim($content).PHP_EOL.";*/".PHP_EOL.";?>".PHP_EOL) && fclose($handle)) ? TRUE : FALSE;
	}
	public function exist($section, $key = NULL) {
		if ($key != NULL ) {
			if (isset($this->data[$section][$key])) {
				return(TRUE);
			} else {
				return(FALSE);
			}
		} else {
			if (isset($this->data[$section])) {
				return(TRUE);
			} else {
				return(FALSE);
			}
		}
	}
	public function get($section, $key) {
		if (isset($this->data[$section][$key])) {
			return $this->data[$section][$key];
		} else {
			return(FALSE);
		}
	}
	public function set($section, $key, $value) {
		if (isset($this->data[$section][$key])) {
			$this->data[$section][$key] = $value;
			return(TRUE);
		} else {
			$this->data[$section][$key] = $value;
			return(FALSE);
		}
	}
	public function delete($section, $key = NULL) {
		if ($key != NULL ) {
			if (isset($this->data[$section][$key])) {
				unset($this->data[$section][$key]);
				return(TRUE);
			} else {
				return(FALSE);
			}
		} else {			
			if (isset($this->data[$section])) {
				unset($this->data[$section]);
				return(TRUE);
			} else {
				return(FALSE);
			}
		}
	}
}
class template {
	protected $file;
	protected $values = array();
	public function open($file) {
		$this->file = $file;
		if($file != '') {
			if(is_readable($file)) {
				$this->file = $file;
				return(TRUE);
			} else {
				return(FALSE);
			}
		}
	}
	public function set($key, $value) {
		$this->values[$key] = $value;
	}
	public function get() {
		if (!file_exists($this->file)) {
			die($this->file);
		}
		$output = file_get_contents($this->file);
		foreach ($this->values as $key => $value) {
			$tagToReplace = "[@$key]";
			$output = str_replace($tagToReplace, $value, $output);
		}
		return $output;
	}
}
class database {
	private $db_user;
	private $db_password;
	private $db_host;
	private $db_name;
	private $db_connection;
	function __construct($host, $name, $password, $user) {
		$this->db_host = $host;
		$this->db_name = $name;
		$this->db_password = $password;
		$this->db_user = $user;
		$this->db_connection = "";
	}
	public function connect() {
		$this->db_connection = mysqli_connect($this->db_host, $this->db_user, $this->db_password, $this->db_name);
		mysqli_set_charset($this->db_connection, 'utf8');
	}
	public function setquery($query) {
		mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
	}
	public function getquery($query) {
		$result = mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
		$returnarray = array ();
		while ($row = mysqli_fetch_array($result)) {
			$returnarray[] = $row;
		}
		return $returnarray;
	}
	public function getquery_rows($query) {
		$result = mysqli_query($this->db_connection, $query) or die(mysqli_error($this->db_connection));
		$rows = mysqli_num_rows($result);
		return $rows;
	}
	public function getquery_id() {
		return mysqli_insert_id($this->db_connection);
	}

	public function backup() {
        $mysqli = new mysqli($this->db_host, $this->db_user, $this->db_password, $this->db_name); 
        $mysqli->select_db($this->db_name); 
        $mysqli->query("SET NAMES 'utf8'");
        $queryTables = $mysqli->query('SHOW TABLES'); 
        while($row = $queryTables->fetch_row()) { 
            $target_tables[] = $row[0]; 
        }
        foreach($target_tables as $table) {
            $result = $mysqli->query('SELECT * FROM '.$table);  
            $fields_amount = $result->field_count;  
            $rows_num=$mysqli->affected_rows;     
            $res = $mysqli->query('SHOW CREATE TABLE '.$table); 
            $TableMLine = $res->fetch_row();
            $content = (!isset($content) ?  '' : $content) . "\n\n".$TableMLine[1].";\n\n";
            for ($i = 0, $st_counter = 0; $i < $fields_amount;   $i++, $st_counter=0) {
                while($row = $result->fetch_row()) {
                    if ($st_counter%100 == 0 || $st_counter == 0 ) {
						$content .= "\nINSERT INTO ".$table." VALUES";
                    }
                    $content .= "\n(";
                    for($j=0; $j<$fields_amount; $j++) { 
                        $row[$j] = str_replace("\n","\\n", addslashes($row[$j]) ); 
                        if (isset($row[$j])) {
                            $content .= '"'.$row[$j].'"' ; 
                        } else {   
                            $content .= '""';
                        }     
                        if ($j<($fields_amount-1)) {
                                $content.= ',';
                        }
                    }
                    $content .=")";
                    if ( (($st_counter+1)%100==0 && $st_counter!=0) || $st_counter+1==$rows_num) {   
                        $content .= ";";
                    } else  {
                        $content .= ",";
                    } 
                    $st_counter=$st_counter+1;
                }
            } $content .="\n\n\n";
        }
		return $content;
	}
	public function format_size($bytes) {
		$sizes = array('B', 'KB', 'MB', 'GB', 'TB', 'PB');
		for($i = 0; $bytes >= 1024 && $i < (count($sizes)-1); $bytes /= 1024, $i++);
		return(round($bytes, 2)." ".$sizes[$i]);
	}
	public function getinfo($info_type = '') {
		if ($info_type == 'server_info') {
			return mysqli_get_server_info($this->db_connection);
		} else if ($info_type == 'server_version') {
			return mysqli_get_server_version($this->db_connection);
		} else if ($info_type == 'client_info') {
			return mysqli_get_client_info($this->db_connection);
		} else if ($info_type == 'client_version') {
			return mysqli_get_client_version($this->db_connection);
		} else if ($info_type == 'database_size') {
			$result = mysqli_query($this->db_connection, "SHOW TABLE STATUS") or die(mysqli_error($this->db_connection));
			$total = 0;
			while($row = mysqli_fetch_array($result)) {
				$total = $total + $row['Data_length']+$row['Index_length'];
			}
			return $total;
		}
	}
}
class user {
	private $user_name = '';
	private $user_password = '';
	private $user_id = '';
	private $user_level = '';
	public function get_level() {
		return $this->user_level;
	}
	public function set_name($user_name='') {
		$this->user_name = $user_name;
	}
	public function get_name() {
		return $this->user_name;
	}
	public function set_password($user_password='') {
		$this->user_password = $user_password;
	}
	public function set_id($user_id='') {
		$this->user_id = $user_id;
	}
	public function get_id() {
		return $this->user_id;
	}
	public function count() {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `users`;";
		$result = $database->getquery($sql);
		return $result[0][0];
	}
	public function get() {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `users` ORDER BY `name`";
		$result = $database->getquery($sql);
		return $result;
	}
	public function random_password() {
		$alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890';
		$random_password = array();
		$alphabet_length = strlen($alphabet) - 1;
		for ($i = 0; $i < 8; $i++) {
			$n = rand(0, $alphabet_length);
			$random_password[] = $alphabet[$n];
		}
		return implode($random_password);
	}
	public function mail_utf8($to, $from_user, $from_email, $subject = '(No subject)', $message = '') {
		$from_user = "=?UTF-8?B?".base64_encode($from_user)."?=";
		$subject = "=?UTF-8?B?".base64_encode($subject)."?=";
		$headers = "From: $from_email\r\n"."MIME-Version: 1.0"."\r\n"."Content-type: text/html; charset=UTF-8"."\r\n";
		return mail($to, $subject, $message, $headers);
	}
	public function reset_user($user_email='', $mail_from_user, $mail_from_email, $mail_subject) {
		Global $config;
		Global $database;
		Global $template;
		Global $language;
		$output = false;
		$sql = "SELECT COUNT(*) FROM `users` WHERE `email`='".$user_email."';";
		$result = $database->getquery($sql);
		if ($result[0][0] == 1) {
			$output = true;
			$sql = "SELECT * FROM `users` WHERE `email`='".$user_email."';";
			$result = $database->getquery($sql);
			$this->set_id($result[0]['id']);
			$this->set_name($result[0]['name']);
			$new_password = $this->random_password();
			$this->set_password($new_password);
			$sql = "UPDATE `users` SET `password` = MD5('".$new_password."') WHERE `id`='".$this->user_id."';";
			$result = $database->setquery($sql);
			$mail_to = $user_email;
			$template_email = new template;
			$template_email->open('email.tpl');
			$template_email->set('title', $config->get('APPLICATION', 'TITLE'));
			$template_email->set('url', $config->get('APPLICATION', 'URL'));
			$template_email->set('description', $config->get('APPLICATION', 'DESCRIPTION'));
			$template_email->set('action', $language->get('STRING', 'REMIND_PASSWORD'));
			$template_email->set('action_description', $language->get('STRING', 'EMAIL_HELP_REMIND'));
			$template_email->set('action_data', $language->get('STRING', 'USER_NAME').' : <b>'.$this->user_name.'</b><br>'.$language->get('STRING', 'PASSWORD').' : <b>'.$new_password.'</b>');
			$mail_message = $template_email->get();
			$this->mail_utf8($mail_to, $mail_from_user, $mail_from_email, $mail_subject, $mail_message);
		} else {
			$output = false;
		}
		return $output;
	}
	public function update_password($new_password) {
		Global $config;
		Global $database;
		$output = false;
		if ($this->user_id == '') {
			$sql = "SELECT COUNT(*) FROM `users` WHERE `name`='".$this->user_name."' AND `password`=MD5('".$this->user_password."') AND `priviledges` > 0;";
		} else {
			$sql = "SELECT COUNT(*) FROM `users` WHERE `id`='".$this->user_id."' AND `priviledges` > 0;";
		}
		$result = $database->getquery($sql);
		if ($result[0][0] == 1) {
			$output = true;
			$sql = "UPDATE `users` SET `password` = MD5('".nl2br($new_password)."') WHERE `name`='".$this->user_name."' AND `password`='".$this->user_password."'  AND `priviledges` > 0;";
			$result = $database->setquery($sql);
			$this->user_password = $new_password;
		} else {
			$output = false;
		}
		return $output;
	}
	public function priviledge($user_id, $priviledges) {
		Global $config;
		Global $database;
		$sql = "UPDATE `users` SET `priviledges` = '".$priviledges."' WHERE `id`='".$user_id."';";
		$result = $database->setquery($sql);
	}
	public function validate() {
		Global $config;
		Global $database;
		$output = false;
		if ($this->user_id == '') {
			$sql = "SELECT COUNT(*) FROM `users` WHERE `name`='".$this->user_name."' AND `password`=MD5('".$this->user_password."') AND `priviledges` > 0;";
		} else {
			$sql = "SELECT COUNT(*) FROM `users` WHERE `id`='".$this->user_id."' AND `priviledges` > 0;";
		}
		$result = $database->getquery($sql);
		if ($result[0][0] == 1) {
			if ($this->user_id == '') {
				$output = true;
				$sql = "SELECT * FROM `users` WHERE `name`='".$this->user_name."' AND `password`=MD5('".$this->user_password."')  AND `priviledges` > 0;";
				$result = $database->getquery($sql);
				$this->user_id = $result[0]['id'];
				$this->user_level = $result[0]['priviledges'];
			} else {
				$output = true;
				$sql = "SELECT * FROM `users` WHERE `id`='".$this->user_id."' AND `priviledges` > 0;";
				$result = $database->getquery($sql);
				$this->user_name = $result[0]['name'];
				$this->user_password = $result[0]['password'];
				$this->user_level = $result[0]['priviledges'];
			}
		} else {
			$output = false;
		}
		return $output;
	}
	public function exist($user_id) {
		Global $config;
		Global $database;
		$output = false;
		$sql = "SELECT COUNT(*) FROM `users` WHERE `id`='".$user_id."';";
		$result = $database->getquery($sql);
		if ($result[0][0] == 1) {
			$output = true;
			$sql = "SELECT * FROM `users` WHERE `id`='".$user_id."';";
			$result = $database->getquery($sql);
			$this->user_id = $result[0]['id'];
			$this->user_level = $result[0]['priviledges'];
			$output = true;
		} else {
			$output = false;
		}
		return $output;
	}	
	public function create($user_name='', $user_password='', $user_email='') {
		Global $config;
		Global $database;
		$sql = "SELECT COUNT(*) FROM `users` WHERE `name`='".$user_name."' OR `email`='".$user_email."';";
		$result = $database->getquery($sql);
		if ($result[0][0] == 0) {
			$sql = "INSERT INTO `users` (`id`, `name`, `password`, `email`, `priviledges`) VALUES (NULL, '".nl2br($user_name)."', MD5('".nl2br($user_password)."'), '".nl2br($user_email)."', '1');";
			$result = $database->setquery($sql);
			$new_user = $database->getquery_id();
			$this->user_id = $new_user;
			return $new_user;
		} else {
			return -1;
		}
	}
	public function delete($user_id) {
		Global $config;
		Global $database;
		$sql = "SELECT * FROM `poems` WHERE `user` = '".$user_id."';";
		$result = $database->getquery($sql);
		for($i = 0; $i < sizeof($result); $i = $i + 1) {
			$sql_comments = "DELETE FROM `comments` WHERE `poem` = '".$result[$i]['id']."';";
			$result_comments = $database->setquery($sql_comments);
			$sql_poems = "DELETE FROM `reports` WHERE `poem` = '".$result[$i]['id']."';";
			$result_poems = $database->setquery($sql_poems);
		}
		$sql_user_poems = "DELETE FROM `poems` WHERE `user` = '".$user_id."';";
		$result_user_poems = $database->setquery($sql_user_poems);
		$sql_user = "DELETE FROM `users` WHERE `id` = '".$user_id."';";
		$result_user = $database->setquery($sql_user);
	}
}	
?>
