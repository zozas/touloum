;<?php
;die();
;/*

[APPLICATION]
	AUTHOR 					= "touloum.gr"
	CONTACT					= "info@touloum.gr"
	COPYRIGHT				= "touloum.gr"
	GOOGLE					= ""
	DESCRIPTION				= "Η μεγαλύτερη συλλογή ποντιακών δίστιχων στο Internet"
	DESCRIPTION_FACEBOOK	= "Εντόπισα αυτό το διστιχο στο touloum.gr! Βοήθησε και εσύ στη διάσωση και διατήρηση της ποντιακής μας κληρονομιάς!"
	DISCLAIMER				= "Απαγορεύεται αυστηρά η κατ οποιδήποτε τρόπο αναδημοσίευση ή χρήση, ολική, μερική ή περιληπτική του περιεχόμενου του ιστοτόπου και οποιαδήποτε δίστιχου χωρίς προηγούμενη γραπτή άδεια του touloum.gr"
	DISTRIBUTION			= "Global"
	KEYWORDS				= "Δίστιχα, δίστιχα, ΔΙΣΤΙΧΑ, διστιχα, Ποντιακά, Πόντος"
	LOG_SIZE				= "5000"
	PLATFORM				= "Tsibon CMS"
	PRODUCT 				= "Τουλούμ"
	ROBOTS					= "FOLLOW,INDEX"
	TITLE					= "Τουλούμ"
	TYPE					= "text/css"
	XUA						= "IE=7"
	URL						= "http://www.touloum.gr"
	VERSION					= "2020.08.01"
	VIEWPORT				= "width=device-width, initial-scale=1, user-scalable=no"
[USERS]
	ROLES					= "4"
[DATABASE]
	HOST					= "localhost";
	NAME					= "ozashot10869com19700_";
	PASSWORD				= "$Sp1rt0.kokoriko";
	USER					= "touloum";
[ENCODING]
	CHARSET					= "text/html; charset=utf-8"
	DATETIME				= "d.m.Y, H:i"
	LANGUAGE				= "language.ini.php"
	ANNOUNCEMENTS			= "language.announcement.ini.php"
	ABOUT					= "language.about.ini.php"
	POEMS					= "language.poems.ini.php"
	PLATFORM				= "language.platform.ini.php"
	TERMS					= "language.terms.ini.php"
[POEMS]
	CATEGORIES				= "53"
	ORIGINS					= "2"
	SEARCH_PAGINATION		= "20"
	SEARCH_PAGINATION_STEP	= "1"
;*/
;?>
