;<?php
;die();
;/*
[ANNOUNCEMENT]
TITLE = 
DATA =
;*/
;?>
