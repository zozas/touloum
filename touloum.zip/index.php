<?php
	ini_set('display_errors', 'On');
	error_reporting(E_ALL | E_STRICT);
	session_start();
	require_once('include.php');
	// Load configuration
	$config = new ini;
	$config->open('config.ini.php');
	$config->read();
	// Load language
	$language = new ini;
	$language->open($config->get('ENCODING', 'LANGUAGE'));
	$language->read();
	// Connect to database
	$database = new database($config->get('DATABASE','HOST'), $config->get('DATABASE','NAME'), $config->get('DATABASE','PASSWORD'), $config->get('DATABASE','USER'));
	$database->connect();
	// Initialize session and log
	$session = new session;
	$log = new log;
	// Initialize poems, comments, reports, statistics
	$poem = new poem;
	$comment = new comment;
	$reports = new reports;
	$statistics = new statistics;	
	// Initialize user data - check for login POST variables or current session login variables
	$user = new user();
	$login_username = '';
	if (isset($_POST['login_username'])) {
		$login_username = $_POST['login_username'];
		$session->set('USER_NAME', $login_username);
	}
	if ($session->exist('USER_NAME'))
		$login_username = $session->get('USER_NAME');
	$login_password = '';
	if (isset($_POST['login_password'])) {
		$login_password = $_POST['login_password'];
		$session->set('USER_PASSWORD', $login_password);
	}
	if ($session->exist('USER_PASSWORD'))
		$login_password = $session->get('USER_PASSWORD');
	$user->set_name($login_username);
	$user->set_password($login_password);
	// Load template
	$template_main = new template;
	$template_main->open('main.tpl');
	$template_main->set('meta_title', $config->get('APPLICATION', 'TITLE'));
	$template_main->set('meta_viewport', $config->get('APPLICATION', 'VIEWPORT'));
	$template_main->set('meta_charset', $config->get('ENCODING', 'CHARSET'));
	$template_main->set('meta_author', $config->get('APPLICATION', 'AUTHOR'));
	$template_main->set('meta_contact', $config->get('APPLICATION', 'CONTACT'));
	$template_main->set('meta_distribution', $config->get('APPLICATION', 'DISTRIBUTION'));
	$template_main->set('meta_google', $config->get('APPLICATION', 'GOOGLE'));
	$template_main->set('meta_product', $config->get('APPLICATION', 'PRODUCT'));
	$template_main->set('meta_robots', $config->get('APPLICATION', 'ROBOTS'));
	$template_main->set('meta_xua', $config->get('APPLICATION', 'XUA'));
	$template_main->set('meta_type', $config->get('APPLICATION', 'TYPE'));
	$template_main->set('meta_version', $config->get('APPLICATION', 'VERSION'));
	$template_main->set('meta_copyright', $config->get('APPLICATION', 'COPYRIGHT'));
	$template_main->set('meta_description', $config->get('APPLICATION', 'DESCRIPTION'));
	$template_main->set('meta_disclaimer', $config->get('APPLICATION', 'DISCLAIMER'));
	$template_main->set('meta_keywords', $config->get('APPLICATION', 'KEYWORDS'));
	$template_main->set('meta_facebook_description', $config->get('APPLICATION', 'DESCRIPTION_FACEBOOK'));
	$template_main->set('terms', $language->get('STRING', 'TERMS'));
	$template_main->set('search', $language->get('STRING', 'SEARCH'));
	$template_main->set('search_poems', $language->get('STRING', 'SEARCH_POEMS'));
	$template_main->set('menu', $language->get('STRING', 'MENU'));
	$template_main->set('page_home', $language->get('STRING', 'HOMEPAGE'));
	$template_main->set('page_admin', $language->get('STRING', 'ADMIN'));
	$template_main->set('page_information', $language->get('STRING', 'INFORMATION'));
	$template_main->set('platform', $language->get('STRING', 'PLATFORM'));
	$template_main->set('about_poems', $language->get('STRING', 'POEMS_ABOUT'));
	$template_main->set('about_us', $language->get('STRING', 'ABOUT_US'));
	$template_main->set('my_poems', $language->get('STRING', 'POEM_MY'));
	$template_main->set('my_poems_count', $poem->count($user->get_id()));
	$template_main->set('members', date($language->get('STRING', 'MEMBERS')));
	$template_main->set('facebook_share', date($language->get('STRING', 'SHARE_FACEBOOK')));
	$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$template_main->set('current_page', $actual_link);
	$template_main->set('contact', $language->get('STRING', 'CONTACT'));
	$template_main->set('members', $language->get('STRING', 'USERS'));
	// Load poem categories
	$template_main->set('poem_add', $language->get('STRING', 'POEM_ADD'));
	$template_main->set('poem_all', $language->get('STRING', 'POEM_ALL'));
	$template_main->set('poem_categories', $language->get('STRING', 'CATEGORIES'));
	$poem_categories_list = "";
	for ($i = 1; $i <= $config->get('POEMS', 'CATEGORIES'); $i = $i + 1) {
		$template_category = new template;
		$template_category->open('categories.tpl');
		$template_category->set('title', $language->get('POEM_CATEGORIES', 'CATEGORY_'.$i));
		$template_category->set('rank', $i);
		$poem_categories_list = $poem_categories_list.$template_category->get();
	}
	$template_main->set('poem_categories_list', $poem_categories_list);
	// Load poem origins categories
	$template_main->set('poem_origins', $language->get('STRING', 'ORIGINS'));
	$poem_origins_list = "";
	for ($i = 1; $i <= $config->get('POEMS', 'ORIGINS'); $i = $i + 1) {
		$template_category = new template;
		$template_category->open('origins.tpl');
		$template_category->set('title', $language->get('POEM_ORIGINS', 'CATEGORY_'.$i));
		$template_category->set('rank', $i);
		$poem_origins_list = $poem_origins_list.$template_category->get();
	}
	$template_main->set('poem_origins_list', $poem_origins_list);
	$template_main->set('poem_drafts', $language->get('STRING', 'POEM_DRAFT')." <strong>".$poem->count_drafts()."</strong>");
	// Initialize actions
	$action = '';
	if (isset($_POST['action']))
		$action = $_POST['action'];
	else
		if (isset($_GET['action']))
			$action = $_GET['action'];
	// Initialize user menu
	if ($user->validate() == true) {
		// User menu
		$template_user = new template;
		$template_user->open('user.tpl');
		$template_user->set('logout', $language->get('STRING', 'LOGOUT'));
		$template_user->set('welcome', $language->get('STRING', 'WELCOME'));
		$template_user->set('user_name', $user->get_name());
		$template_user->set('change', $language->get('STRING', 'CHANGE'));
		$template_user->set('my_poem', $language->get('STRING', 'POEM_MY'));
		$template_user->set('password_change', $language->get('STRING', 'PASSWORD_CHANGE'));
		$template_user->set('user_password_old', $language->get('STRING', 'PASSWORD_OLD'));
		$template_user->set('user_password_new', $language->get('STRING', 'PASSWORD_NEW'));
		$template_user->set('poems_added_by_me', $language->get('STRING', 'POEM_ADDED_BY_ME'));
		$template_user->set('received', $language->get('STRING', 'RECEIVED'));
		$template_user->set('total_comments', $statistics->user_comments($user->get_id()));
		$template_user->set('comments_stored', $language->get('STRING', 'COMMENTS'));
		$template_user->set('total_reports', $statistics->user_reports($user->get_id()));
		$template_user->set('reports_stored', $language->get('STRING', 'REPORTS'));
		$template_user->set('total_likes', $statistics->user_likes($user->get_id()));
		$template_user->set('likes_stored', $language->get('STRING', 'LIKES'));		
		$template_user->set('poems', $language->get('STRING', 'POEMS'));
		$template_user->set('add', $language->get('STRING', 'ADD'));
		$template_user->set('user_level_info', $language->get('STRING', 'USER_LEVEL'));
		$template_user->set('user_level', $language->get('USERS', 'CATEGORY_'.$user->get_level()));
		$template_user->set('total_poems', $poem->count($user->get_id()));
		$template_user->set('poems_pending', $language->get('STRING', 'POEM_PENDING'));
		$template_user->set('total_poems_pending', $poem->count_pending($user->get_id()));
		$template_main->set('menu_user', $template_user->get());
	} else {
		// Login form
		$template_login = new template;
		$template_login->open('login.tpl');
		$template_login->set('user_name', $language->get('STRING', 'USER_NAME'));
		$template_login->set('user_password', $language->get('STRING', 'PASSWORD'));
		$template_login->set('login_help', $language->get('STRING', 'LOGIN_HELP'));
		$template_login->set('login', $language->get('STRING', 'LOGIN'));
		$template_login->set('remind', $language->get('STRING', 'REMIND'));
		$template_login->set('register', $language->get('STRING', 'REGISTER'));
		$template_login->set('remind_help', $language->get('STRING', 'REMIND_HELP'));
		$template_login->set('user_email', $language->get('STRING', 'EMAIL'));
		$template_login->set('register_help', $language->get('STRING', 'REGISTER_HELP'));		
		$template_main->set('menu_user', $template_login->get());
	}
	// Load reports management menu
	if ($user->get_level() > 1) {
		$template_main->set('report_management', "<li><a href='index.php?action=report_management'>".$language->get('STRING', 'REPORT_MANAGEMENT')." <strong>".$reports->count_pending()."</strong></a></li>");
		$template_main->set('log_management', "<li><a href='index.php?action=log_management'>".$language->get('STRING', 'LOG_MANAGEMENT')."</a></li>");
	} else {
		$template_main->set('report_management', '');
		$template_main->set('log_management', '');
	}
	if ($user->get_level() > 2) {
		$template_main->set('news_management', "<li><a href='index.php?action=news_management'>".$language->get('STRING', 'NEWS_MANAGEMENT')."</a></li>");
		$template_main->set('user_management', "<li><a href='index.php?action=user_management'>".$language->get('STRING', 'USER_MANAGEMENT')." <strong>".$user->count()."</strong></a></li>");
	} else {
		$template_main->set('news_management', '');
		$template_main->set('user_management', '');
	}
	// Load user management menu
	if ($action=='terms') {
		$template_terms = new template;
		$template_terms->open('terms.tpl');
		$language_terms = new ini;
		$language_terms->open($config->get('ENCODING', 'TERMS'));
		$language_terms->read();
		$template_terms->set('title', $language_terms->get('STRING', 'TERMS'));
		$template_terms->set('disclaimer', $language_terms->get('TERMS', 'TERM_DISCLAIMER'));
		$total_terms = 1;
		while ($language_terms->exist('TERMS', 'TERM_'.$total_terms.'_TITLE'))
			$total_terms = $total_terms + 1;		
		$total_terms = $total_terms - 1;
		$legal = '';
		for ($i = 1; $i <= $total_terms; $i = $i + 1) {
			$template_legal = new template;
			$template_legal->open('legal.tpl');
			$template_legal->set('title', $language_terms->get('TERMS', 'TERM_'.$i.'_TITLE'));
			$template_legal->set('data', $language_terms->get('TERMS', 'TERM_'.$i.'_DATA'));
			$legal = $legal.$template_legal->get();
		}
		$template_terms->set('legal', $legal);
		$template_main->set('page_content',  $template_terms->get());
	} else if ($action=='login') {
		$log->update(1, '', $user->get_id(), $_SERVER['REMOTE_ADDR']);
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php");
		$template_main->set('page_content',  $template_redirect->get());
	} else if ($action=='logout') {
		$log->update(2, '', $user->get_id(), $_SERVER['REMOTE_ADDR']);
		$session->erase_session();
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php");
		$template_main->set('page_content',  $template_redirect->get());
	} else if ($action=='remind') {
		$session->erase_session();
		$email = '';
		if (isset($_POST['login_email'])) {
			$email = $_POST['login_email'];
		}
		$log->update(3, $email, '', $_SERVER['REMOTE_ADDR']);
		$user->reset_user($email, $config->get('APPLICATION','AUTHOR'), $config->get('APPLICATION','CONTACT'), $language->get('STRING','REMIND_PASSWORD'));
		$template_warning = new template;
		$template_warning->open('warning.tpl');
		$template_warning->set('title', $language->get('STRING', 'REMIND_PASSWORD'));
		$template_warning->set('message', $language->get('STRING', 'REMIND_PASSWORD_HELP'));
		$template_warning->set('actions', '');
		$template_main->set('page_content',  $template_warning->get());
	} else if ($action=='register') {
		$template_register = new template;
		$template_register->open('register.tpl');
		$template_register->set('register', $language->get('STRING', 'REGISTER'));
		$template_register->set('register_form', $language->get('STRING', 'REGISTER_FORM'));
		$template_register->set('register_new_user', $language->get('STRING', 'REGISTER_NEW_USER'));
		$template_register->set('user_name', $language->get('STRING', 'USER_NAME'));
		$template_register->set('register_password', $language->get('STRING', 'REGISTER_PASSWORD'));
		$template_register->set('user_email', $language->get('STRING', 'EMAIL'));
		$template_register->set('register_disclaimer', $language->get('STRING', 'REGISTER_DISCLAIMER'));
		$template_main->set('page_content',  $template_register->get());
	} else if ($action=='password') {
		$login_password_new = '';
		if (isset($_POST['login_password_new']))
			$login_password_new = $_POST['login_password_new'];
		else
			if (isset($_GET['login_password_new']))
				$login_password_new = $_GET['login_password_new'];
		$login_password_old = '';
		if (isset($_POST['login_password_old']))
			$login_password_old = $_POST['login_password_old'];
		else
			if (isset($_GET['login_password_old']))
				$login_password_old = $_GET['login_password_old'];
		if ($user->validate() == true) {
			if($login_password_old  == $session->get('USER_PASSWORD')) {			
				$login_password = $login_password_new;
				$log->update(4, '', $user->get_id(), $_SERVER['REMOTE_ADDR']);
				$user->update_password($login_password_new);
				$session->set('USER_PASSWORD', $login_password_new);
				$user->set_password($login_password_new);
			}
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php");
		$template_main->set('page_content',  $template_redirect->get());
	} else if ($action=='about_us') {
		$template_page = new template;
		$template_page->open('page.tpl');
		$template_page->set('title', $language->get('STRING', 'ABOUT_US_TITLE'));
		$page_context = new ini;
		$page_context->open($config->get('ENCODING', 'ABOUT'));
		$page_context->read();
		$template_page->set('content', $page_context->get('STRING', 'TEXT'));
		$template_main->set('page_content',  $template_page->get());
	} else if ($action=='about_poems') {
		$template_page = new template;
		$template_page->open('page.tpl');
		$template_page->set('title', $language->get('STRING', 'POEMS_ABOUT_TITLE'));
		$page_context = new ini;
		$page_context->open($config->get('ENCODING', 'POEMS'));
		$page_context->read();
		$template_page->set('content', $page_context->get('STRING', 'TEXT'));
		$template_main->set('page_content',  $template_page->get());
	} else if ($action=='new') {
		$login_username = '';
		if (isset($_POST['login_username']))
			$login_username = $_POST['login_username'];
		else
			if (isset($_GET['login_username']))
				$login_username = $_GET['login_username'];
		$login_email = '';
		if (isset($_POST['login_email']))
			$login_email = $_POST['login_email'];
		else
			if (isset($_GET['login_email']))
				$login_email = $_GET['login_email'];
		$terms = '';
		if (isset($_POST['terms']))
			$terms = $_POST['terms'];
		else
			if (isset($_GET['terms']))
				$terms = $_GET['contact_message'];
		if ($login_username != '' && $login_email != '') {
			if($terms == 1) {
				$new_user = $user->create($login_username, '', $login_email);
				if ($new_user > 0) {
					$current_user = new user;
					$current_user->set_id($new_user);
					if ($current_user->validate()==true) {
						$log->update(5, '', $current_user->get_id(), $_SERVER['REMOTE_ADDR']);
						$current_user->reset_user($login_email, $config->get('APPLICATION','TITLE'), $config->get('APPLICATION','CONTACT'), $language->get('STRING','REMIND_PASSWORD'));
					}
					$session->erase_session();
					$template_warning = new template;
					$template_warning->open('warning.tpl');
					$template_warning->set('title', $language->get('STRING', 'REGISTER_NEW_USER'));
					$template_warning->set('message', $language->get('STRING', 'REGISTER_SUCCESS'));
					$template_warning->set('actions', '');
					$template_main->set('page_content',  $template_warning->get());
				} else {
					$template_warning = new template;
					$template_warning->open('warning.tpl');
					$template_warning->set('title', $language->get('STRING', 'REGISTER_NEW_USER'));
					$template_warning->set('message', $language->get('STRING', 'REGISTER_ERROR_COMBINE'));
					$template_warning->set('actions', '');
					$template_main->set('page_content',  $template_warning->get());
				}
			} else {
				$template_warning = new template;
				$template_warning->open('warning.tpl');
				$template_warning->set('title', $language->get('STRING', 'REGISTER_NEW_USER'));
				$template_warning->set('message', $language->get('STRING', 'REGISTER_TERMS_ACCEPT'));
				$template_warning->set('actions', '');
				$template_main->set('page_content',  $template_warning->get());
			}
		} else {
			$template_warning = new template;
			$template_warning->open('warning.tpl');
			$template_warning->set('title', $language->get('STRING', 'REGISTER_NEW_USER'));
			$template_warning->set('message', $language->get('STRING', 'REGISTER_ERROR_EMPTY'));
			$template_warning->set('actions', '');
			$template_main->set('page_content',  $template_warning->get());
		}
	} else if ($action=='add') {
		$template_add = new template;
		$template_add->open('add.tpl');
		$template_add->set('add_new_poem', $language->get('STRING', 'POEM_ADD_NEW'));
		$template_add->set('add', $language->get('STRING', 'ADD'));
		$template_add->set('poem_disclaimer', $language->get('STRING', 'POEM_DISCLAIMER'));
		$template_add->set('poem', $language->get('STRING', 'POEM'));
		$template_add->set('category', $language->get('STRING', 'CATEGORY'));
		$template_add->set('poem_name', $language->get('STRING', 'CREATOR_NAME'));
		$template_add->set('owner_ask', $language->get('STRING', 'OWNER_ASK'));
		if ($user->get_name() != '')
			$template_add->set('validated_user', '1');
		else
			$template_add->set('validated_user', '0');
		$template_add->set('owner_name', $user->get_name());
		$poem_category = '';
		for ($i = 1; $i <= $config->get('POEMS', 'CATEGORIES'); $i = $i + 1) {
			$poem_category = $poem_category."<option value='".$i."'>".$language->get('POEM_CATEGORIES', 'CATEGORY_'.$i)."</option>";
		}
		$template_add->set('poem_category', $poem_category);
		$template_add->set('origin', $language->get('STRING', 'ORIGIN'));
		$template_main->set('page_content',  $template_add->get());
	} else if ($action=='draft') {
		if ($user->get_level() > 0) {
			$poem_data = '';
			if (isset($_POST['poem_data']))
				$poem_data = $_POST['poem_data'];
			else
				if (isset($_GET['poem_data']))
					$poem_data = $_GET['poem_data'];
			$poem_category = '';
			if (isset($_POST['poem_category']))
				$poem_category = $_POST['poem_category'];
			else
				if (isset($_GET['poem_category']))
					$poem_category = $_GET['poem_category'];
			$poem_origin = '2';
			if (isset($_POST['poem_origin']))
				$poem_origin = $_POST['poem_origin'];
			else
				if (isset($_GET['poem_origin']))
					$poem_origin = $_GET['poem_origin'];
			$poem_name = '';
			if (isset($_POST['poem_name']))
				$poem_name = $_POST['poem_name'];
			else
				if (isset($_GET['poem_name']))
					$poem_name = $_GET['poem_name'];
			$poem_owner = '';
			if (isset($_POST['owner']))
				$poem_owner = $_POST['owner'];
			else
				if (isset($_GET['owner']))
					$poem_owner = $_GET['owner'];
			if ($poem_owner == '1') {
				$poem_origin = '1';
			} else {
				if ($poem_name != '') {
					$poem_origin = '1';
				} else {
					$poem_origin = '2';
				}
			}
			$poem_user_id = $user->get_id();
			if ($poem_user_id == NULL || $poem_user_id == '')
				$poem_user_id = 0;
			$poem->create($poem_data, $poem_category, $poem_origin, $poem_user_id, $poem_name);
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content',  $template_redirect->get());
		} else {
			$template_warning = new template;
			$template_warning->open('warning.tpl');
			$template_warning->set('title', $language->get('STRING', 'SORRY'));
			$template_warning->set('message', $language->get('STRING', 'REGISTER_ONLY'));
			$template_register = new template;
			$template_register->open('register.tpl');
			$template_register->set('register', $language->get('STRING', 'REGISTER'));
			$template_register->set('register_form', $language->get('STRING', 'REGISTER_FORM'));
			$template_register->set('register_new_user', $language->get('STRING', 'REGISTER_NEW_USER'));
			$template_register->set('user_name', $language->get('STRING', 'USER_NAME'));
			$template_register->set('user_password', $language->get('STRING', 'PASSWORD'));
			$template_register->set('user_email', $language->get('STRING', 'EMAIL'));
			$template_register->set('register_disclaimer', $language->get('STRING', 'REGISTER_DISCLAIMER'));
			$template_warning->set('actions', $template_register->get());
			$template_main->set('page_content',  $template_warning->get());
		}
	} else if ($action=='search') {
		$page = '0';
		if (isset($_POST['page']))
			$page = $_POST['page'];
		else
			if (isset($_GET['page']))
				$page = $_GET['page'];
		$query = '';
		if (isset($_POST['query']))
			$query = $_POST['query'];
		else
			if (isset($_GET['query']))
				$query = $_GET['query'];
		$search_results = $poem->search($query, '', '', '', '1', $page);
		$log->update(12, $query, '', $_SERVER['REMOTE_ADDR']);
		$template_main->set('page_content',  handle_search_results($search_results, $page, $action, $query));
	} else if ($action=='search_category') {
		$page = '0';
		if (isset($_POST['page']))
			$page = $_POST['page'];
		else
			if (isset($_GET['page']))
				$page = $_GET['page'];
		$category = '1';
		if (isset($_GET['category'])) {
			$category = $_GET['category'];
		}
		$query = $language->get('POEM_CATEGORIES', 'CATEGORY_'.$category);
		$search_results = $poem->search('', '', $category, '', '1', $page);
		$template_main->set('page_content',  handle_search_results($search_results, $page, $action, $query));
	} else if ($action=='search_origin') {
		$page = '0';
		if (isset($_POST['page']))
			$page = $_POST['page'];
		else
			if (isset($_GET['page']))
				$page = $_GET['page'];
		$category = '1';
		if (isset($_GET['category'])) {
			$category = $_GET['category'];
		}
		$query = $language->get('POEM_ORIGINS', 'CATEGORY_'.$category);
		$search_results = $poem->search('', '', '', $category, '1', $page);
		$template_main->set('page_content',  handle_search_results($search_results, $page, $action, $query));
	} else if ($action=='search_user') {
		$page = '0';
		if (isset($_POST['page']))
			$page = $_POST['page'];
		else
			if (isset($_GET['page']))
				$page = $_GET['page'];
		$search_user = $user->get_id();
		if ($search_user == NULL || $search_user == '')
			$search_user = '1234567890';
		if (isset($_GET['search_user'])) {
			$search_user = $_GET['search_user'];
		}
		$query = '';
		$current_user = new user;
		$current_user->set_id($search_user);
		if ($current_user->validate()==true) {
			$query = $current_user->get_name();
		} else {
			$query = $user->get_name();
		}
		$search_results = $poem->search('', $search_user, '', '', '1', $page);
		$template_main->set('page_content',  handle_search_results($search_results, $page, $action, $query));
	} else if ($action=='search_draft') {
		$page = '0';
		if (isset($_POST['page']))
			$page = $_POST['page'];
		else
			if (isset($_GET['page']))
				$page = $_GET['page'];
		$query = $language->get('STRING', 'POEM_DRAFT_PENDING');
		$search_results = $poem->search('', '', '', '', '0', $page);
		$template_main->set('page_content',  handle_search_results($search_results, $page, $action, $query));
	} else if ($action=='search_all') {
		$page = '0';
		if (isset($_POST['page']))
			$page = $_POST['page'];
		else
			if (isset($_GET['page']))
				$page = $_GET['page'];
		$query = $language->get('STRING', 'POEM_ALL_SEARCH');
		$search_results = $poem->search('', '', '', '', '1', $page);
		$template_main->set('page_content',  handle_search_results($search_results, $page, $action, $query));
	} else if ($action=='like') {
		if ($user->get_level() > 0) {		
			$poem_id = '0';
			if (isset($_POST['poem']))
				$poem_id = $_POST['poem'];
			else
				if (isset($_GET['poem']))
					$poem_id = $_GET['poem'];
			$current_poem = $poem->get($poem_id);
			if ($user->get_level() > 0 && $current_poem['user'] != $user->get_id()) {
				$poem->like($poem_id);
				$template_redirect = new template;
				$template_redirect->open('redirect.tpl');
				$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
				$template_main->set('page_content',  $template_redirect->get());
			} else {
				$template_warning = new template;
				$template_warning->open('warning.tpl');
				$template_warning->set('title', $language->get('STRING', 'SORRY'));
				$template_warning->set('message', $language->get('STRING', 'LIKE_DICLAIMER'));
				$template_warning->set('actions', '');
				$template_main->set('page_content',  $template_warning->get());
			}
		} else {
			$template_warning = new template;
			$template_warning->open('warning.tpl');
			$template_warning->set('title', $language->get('STRING', 'SORRY'));
			$template_warning->set('message', $language->get('STRING', 'REGISTER_ONLY'));
			$template_register = new template;
			$template_register->open('register.tpl');
			$template_register->set('register', $language->get('STRING', 'REGISTER'));
			$template_register->set('register_form', $language->get('STRING', 'REGISTER_FORM'));
			$template_register->set('register_new_user', $language->get('STRING', 'REGISTER_NEW_USER'));
			$template_register->set('user_name', $language->get('STRING', 'USER_NAME'));
			$template_register->set('user_password', $language->get('STRING', 'PASSWORD'));
			$template_register->set('user_email', $language->get('STRING', 'EMAIL'));
			$template_register->set('register_disclaimer', $language->get('STRING', 'REGISTER_DISCLAIMER'));
			$template_warning->set('actions', $template_register->get());
			$template_main->set('page_content',  $template_warning->get());
		}
	} else if ($action=='approve') {
		$poem_id = '0';
		if (isset($_POST['poem']))
			$poem_id = $_POST['poem'];
		else
			if (isset($_GET['poem']))
				$poem_id = $_GET['poem'];
		if ($user->get_level() > 1) {
			$log->update(6, $poem_id, $user->get_id(), $_SERVER['REMOTE_ADDR']);
			$poem->approve($poem_id);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
		$template_main->set('page_content',  $template_redirect->get());
	} else if ($action=='disapprove') {
		$poem_id = '0';
		if (isset($_POST['poem']))
			$poem_id = $_POST['poem'];
		else
			if (isset($_GET['poem']))
				$poem_id = $_GET['poem'];
		if ($user->get_level() > 1) {
			$log->update(7, $poem_id, $user->get_id(), $_SERVER['REMOTE_ADDR']);
			$poem->disapprove($poem_id);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
		$template_main->set('page_content',  $template_redirect->get());
	} else if ($action=='edit') {
		$poem_id = '0';
		if (isset($_POST['poem']))
			$poem_id = $_POST['poem'];
		else
			if (isset($_GET['poem']))
				$poem_id = $_GET['poem'];
		$current_poem = $poem->get($poem_id);	
		if ($user->get_level() > 1 || $current_poem['user'] == $user->get_id()) {
			$template_review = new template;
			$template_review->open('review.tpl');
			$template_review->set('review_poem', $language->get('STRING', 'POEM_REVIEW'));
			$template_review->set('poem_disclaimer', $language->get('STRING', 'POEM_DISCLAIMER'));
			$template_review->set('save', $language->get('STRING', 'SAVE'));
			$template_review->set('poem', $language->get('STRING', 'POEM'));
			$template_review->set('category', $language->get('STRING', 'CATEGORY'));
			$template_review->set('poem_name', $language->get('STRING', 'CREATOR_NAME'));
			$template_review->set('poem_name_data', $current_poem['name']);
			$template_review->set('poem_user', $current_poem['user']);
			if ($current_poem['name'] == $user->get_name()) {
				$template_review->set('owner_checked', 'checked');
			} else {
				$template_review->set('owner_checked', '');
			}
			$template_review->set('current_poem', $current_poem['data']);
			$template_review->set('owner_ask', $language->get('STRING', 'OWNER_ASK'));
			if ($user->get_name() != '')
				$template_review->set('validated_user', '1');
			else
				$template_review->set('validated_user', '0');
			$current_user = new user;
			$current_user->set_id($current_poem['data']);
			if ($current_user->validate()==true) {
				$template_review->set('owner_name', $current_user->get_name());
			} else {
				$template_review->set('owner_name', $user->get_name());
			}
			$poem_category = "<option value='".$current_poem['category']."' selected='selected'> * ".$language->get('POEM_CATEGORIES', 'CATEGORY_'.$current_poem['category'])."</option>";;
			for ($i = 1; $i <= $config->get('POEMS', 'CATEGORIES'); $i = $i + 1) {
				$poem_category = $poem_category."<option value='".$i."'>".$language->get('POEM_CATEGORIES', 'CATEGORY_'.$i)."</option>";
			}
			$template_review->set('poem_category', $poem_category);
			$template_review->set('origin', $language->get('STRING', 'ORIGIN'));
			$template_review->set('cancel', $language->get('STRING', 'CANCEL'));
			$template_review->set('poem_id', $poem_id);
			$template_review->set('delete', $language->get('STRING', 'DELETE'));
			$template_main->set('page_content',  $template_review->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
			$template_main->set('page_content',  $template_redirect->get());
		}
	} else if ($action=='review') {
		$poem_id = '0';
		if (isset($_POST['poem']))
			$poem_id = $_POST['poem'];
		else
			if (isset($_GET['poem']))
				$poem_id = $_GET['poem'];
		$poem_data = '';
		if (isset($_POST['poem_data']))
			$poem_data = $_POST['poem_data'];
		else
			if (isset($_GET['poem_data']))
				$poem_data = $_GET['poem_data'];
		$poem_category = '';
		if (isset($_POST['poem_category']))
			$poem_category = $_POST['poem_category'];
		else
			if (isset($_GET['poem_category']))
				$poem_category = $_GET['poem_category'];
		$poem_origin = '2';
		if (isset($_POST['poem_origin']))
			$poem_origin = $_POST['poem_origin'];
		else
			if (isset($_GET['poem_origin']))
				$poem_origin = $_GET['poem_origin'];
		if (isset($_POST['poem_name']))
			$poem_name = $_POST['poem_name'];
		else
			if (isset($_GET['poem_name']))
				$poem_name = $_GET['poem_name'];
		$poem_owner = '';
		if (isset($_POST['owner']))
			$poem_owner = $_POST['owner'];
		else
			if (isset($_GET['owner']))
				$poem_owner = $_GET['owner'];
		if ($poem_owner == '1') {
			$poem_origin = '1';
		} else {
			if ($poem_name != '') {
				$poem_origin = '1';
			} else {
				$poem_origin = '2';
			}
		}
		$poem_user_id = '0';
		if (isset($_POST['poem_user']))
			$poem_user_id = $_POST['poem_user'];
		else
			if (isset($_GET['poem_user']))
				$poem_user_id = $_GET['poem_user'];
		$current_poem = $poem->get($poem_id);
		if ($user->get_level() > 1 || $current_poem['user'] == $user->get_id()) {
			$poem->update($poem_id, $poem_data, $poem_category, $poem_origin, $poem_user_id, $poem_name);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='delete') {
		$poem_id = '0';
		if (isset($_POST['poem']))
			$poem_id = $_POST['poem'];
		else
			if (isset($_GET['poem']))
				$poem_id = $_GET['poem'];
		$current_poem = $poem->get($poem_id);
		if ($user->get_level() > 1 || $current_poem['user'] == $user->get_id()) {
			$log->update(8, $current_poem['data'], $user->get_id(), $_SERVER['REMOTE_ADDR']);
			$poem->delete($poem_id);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php");
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='delete_comment') {
		$comment_id = '0';
		if (isset($_POST['comment']))
			$comment_id = $_POST['comment'];
		else
			if (isset($_GET['comment']))
				$comment_id = $_GET['comment'];		
		$current_comments = $comment->get($comment_id);
		if ($user->get_level() > 1) {
			$log->update(9, $current_comments['data'], $user->get_id(), $_SERVER['REMOTE_ADDR']);
			$comment->delete($comment_id);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=view&poem=".$current_comments['poem']);
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='annotate') {
		if ($user->get_level() > 0) {
			$poem_id = '0';
			if (isset($_POST['poem_id']))
				$poem_id = $_POST['poem_id'];
			else
				if (isset($_GET['poem_id']))
					$poem_id = $_GET['poem_id'];	
			$annotate_data = '';
			if (isset($_POST['annotate_data']))
				$annotate_data = $_POST['annotate_data'];
			else
				if (isset($_GET['annotate_data']))
					$annotate_data = $_GET['annotate_data'];
			if ($user->get_level() > 0) {
				$log->update(10, $annotate_data, $user->get_id(), $_SERVER['REMOTE_ADDR']);
				$comment->create($poem_id, $annotate_data, $user->get_id());
			}
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
			$template_main->set('page_content', $template_redirect->get());
		} else {
			$template_warning = new template;
			$template_warning->open('warning.tpl');
			$template_warning->set('title', $language->get('STRING', 'SORRY'));
			$template_warning->set('message', $language->get('STRING', 'REGISTER_ONLY'));
			$template_register = new template;
			$template_register->open('register.tpl');
			$template_register->set('register', $language->get('STRING', 'REGISTER'));
			$template_register->set('register_form', $language->get('STRING', 'REGISTER_FORM'));
			$template_register->set('register_new_user', $language->get('STRING', 'REGISTER_NEW_USER'));
			$template_register->set('user_name', $language->get('STRING', 'USER_NAME'));
			$template_register->set('user_password', $language->get('STRING', 'PASSWORD'));
			$template_register->set('user_email', $language->get('STRING', 'EMAIL'));
			$template_register->set('register_disclaimer', $language->get('STRING', 'REGISTER_DISCLAIMER'));
			$template_warning->set('actions', $template_register->get());
			$template_main->set('page_content',  $template_warning->get());
		}
	} else if ($action=='report') {
		$poem_id = '0';
		if (isset($_POST['poem_id']))
			$poem_id = $_POST['poem_id'];
		else
			if (isset($_GET['poem_id']))
				$poem_id = $_GET['poem_id'];
		$report_data = '';
		if (isset($_POST['report_data']))
			$report_data = $_POST['report_data'];
		else
			if (isset($_GET['report_data']))
				$report_data = $_GET['report_data'];
		$log->update(11, $report_data, $user->get_id(), $_SERVER['REMOTE_ADDR']);
		$reports->create($poem_id, $report_data, $user->get_id());
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=view&poem=".$poem_id);
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='delete_report') {
		$report_id = '0';
		if (isset($_POST['report']))
			$report_id = $_POST['report'];
		else
			if (isset($_GET['report']))
				$report_id = $_GET['report'];
		if ($user->get_level() > 1) {
			$current_report = $reports->get($report_id);
			$log->update(11, $current_report['data'], $user->get_id(), $_SERVER['REMOTE_ADDR']);
			$reports->delete($report_id);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=report_management");
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='conclude_report') {
		$report_id = '0';
		if (isset($_POST['report']))
			$report_id = $_POST['report'];
		else
			if (isset($_GET['report']))
				$report_id = $_GET['report'];
		if ($user->get_level() > 1) {
			$reports->conclude($report_id);
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php?action=report_management");
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='backup_export') {
		if ($user->get_level() > 2) {
			$data_exported = $database->backup();
			header('Content-Disposition: attachment; filename="backup_'.date('m-d-Y_hia').'.sql"');
			header('Content-Type: text/plain');
			header('Content-Length: ' . strlen($data_exported));
			header('Connection: close');
			echo $data_exported;
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='backup') {
		if ($user->get_level() > 2) {
			$template_backup = new template;
			$template_backup->open('backup.tpl');
			$template_backup->set('title', $language->get('STRING', 'BACKUPS'));
			$template_backup->set('backup_server_info', $language->get('STRING', 'BACKUP_SERVER_INFO'));
			$template_backup->set('server_info', $database->getinfo('server_info'));
			$template_backup->set('backup_server_version', $language->get('STRING', 'BACKUP_SERVER_VERSION'));
			$template_backup->set('server_version', $database->getinfo('server_version'));
			$template_backup->set('backup_client_info', $language->get('STRING', 'BACKUP_CLIENT_INFO'));
			$template_backup->set('client_info', $database->getinfo('client_info'));
			$template_backup->set('backup_client_version', $language->get('STRING', 'BACKUP_CLIENT_VERSION'));
			$template_backup->set('client_version', $database->getinfo('client_version'));
			$template_backup->set('backup_database_size', $language->get('STRING', 'BACKUP_DATABASE_SIZE'));
			$database_size = $database->format_size($database->getinfo('database_size'));
			$template_backup->set('database_size', $database_size);			
			$template_backup->set('backup_database_size', $language->get('STRING', 'BACKUP_DATABASE_SIZE'));
			$template_backup->set('data_exported', $language->get('STRING', 'BACKUP_DATA_EXPORTED'));
			$data_exported = $database->backup();
			$template_backup->set('data', $data_exported);
			$template_backup->set('backup_db_export', $language->get('STRING', 'BACKUP_DATABASE_EXPORT'));
			$template_main->set('page_content', $template_backup->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='logexport') {
		if ($user->get_level() > 1) {
			$data_exported = json_encode($log->backup());
			header('Content-Disposition: attachment; filename="backup_'.date('m-d-Y_hia').'.log"');
			header('Content-Type: text/plain');
			header('Content-Length: ' . strlen($data_exported));
			header('Connection: close');
			echo $data_exported;
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='logclean') {
		if ($user->get_level() > 1) {
			$log->update(13, '', $user->get_id(), $_SERVER['REMOTE_ADDR']);
			$log->clean();
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php?action=log_management");
			$template_main->set('page_content', $template_redirect->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='news_management') {
		if ($user->get_level() > 2) {
			$template_news = new template;
			$template_news->open('news.tpl');
			$template_news->set('title', $language->get('STRING', 'NEWS_EDIT'));
			$template_news->set('disclaimer', $language->get('STRING', 'NEWS_DISCLAIMER'));
			$template_news->set('news_title', $language->get('STRING', 'TITLE'));
			$template_news->set('news_text', $language->get('STRING', 'TEXT'));
			$announcement = new ini;
			$announcement->open($config->get('ENCODING', 'ANNOUNCEMENTS'));
			$announcement->read();
			$template_news->set('curent_title', $announcement->get('ANNOUNCEMENT', 'TITLE'));
			$template_news->set('current_data', $announcement->get('ANNOUNCEMENT', 'DATA'));
			$template_news->set('add', $language->get('STRING', 'ADD'));
			$template_news->set('delete', $language->get('STRING', 'DELETE'));
			$template_main->set('page_content', $template_news->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='news_save') {
		$news_title = '';
		if (isset($_POST['news_title']))
			$news_title = $_POST['news_title'];
		else
			if (isset($_GET['news_title']))
				$news_title = $_GET['news_title'];
		$news_text = '';
		if (isset($_POST['news_text']))
			$news_text = $_POST['news_text'];
		else
			if (isset($_GET['news_text']))
				$news_text = $_GET['news_text'];
		if ($user->get_level() > 2) {
			$announcement = new ini;
			$announcement->open($config->get('ENCODING', 'ANNOUNCEMENTS'));
			$announcement->read();
			$announcement->set('ANNOUNCEMENT', 'TITLE', $news_title);
			$announcement->set('ANNOUNCEMENT', 'DATA', $news_text);
			$announcement->write();
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php");
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='news_clear') {
		if ($user->get_level() > 2) {
			$announcement = new ini;
			$announcement->open($config->get('ENCODING', 'ANNOUNCEMENTS'));
			$announcement->read();
			$announcement->set('ANNOUNCEMENT', 'TITLE', '');
			$announcement->set('ANNOUNCEMENT', 'DATA', '');
			$announcement->write();
		}
		$template_redirect = new template;
		$template_redirect->open('redirect.tpl');
		$template_redirect->set('url', "index.php");
		$template_main->set('page_content', $template_redirect->get());
	} else if ($action=='log_management') {
		if ($user->get_level() > 1) {
			$template_log = new template;
			$template_log->open('log.tpl');
			$template_log->set('title', $language->get('STRING', 'LOG'));
			$template_log->set('log_events', $language->get('STRING', 'LOG_EVENTS'));
			$template_log->set('disclaimer', $language->get('STRING', 'LOG_DISCLAIMER'));
			$template_log->set('date', $language->get('STRING', 'DATE'));
			$template_log->set('event', $language->get('STRING', 'EVENT'));
			$template_log->set('data', $language->get('STRING', 'DATA'));
			$template_log->set('user', $language->get('STRING', 'USER'));
			$template_log->set('logclean', $language->get('STRING', 'LOG_CLEAN'));
			$template_log->set('log_file_size', $language->get('STRING', 'LOG_SIZE'));
			$template_log->set('size', $config->get('APPLICATION', 'LOG_SIZE'));
			$template_log->set('log_file_current_size', $language->get('STRING', 'LOG_SIZE_CURRENT'));
			$template_log->set('backup_db', $language->get('STRING', 'BACKUP'));
			$template_log->set('current_size', $log->count());
			$current_log = $log->get();
			$log_entries = '';
			for($i = 0; $i < sizeof($current_log); $i = $i + 1) {
				$template_loglist = new template;
				$template_loglist->open('loglist.tpl');
				$template_loglist->set('date', date($config->get('ENCODING', 'DATETIME'), strtotime($current_log[$i]['date'])));
				$template_loglist->set('ip', $current_log[$i]['ip']);
				$template_loglist->set('action', $language->get('LOG', 'CATEGORY_'.$current_log[$i]['action']));
				if ($current_log[$i]['user'] == 0 || $current_log[$i]['user'] == '') {
					$template_loglist->set('user', $language->get('USERS', 'CATEGORY_0'));
				} else {
					$current_user = new user;
					$current_user->set_id($current_log[$i]['user']);
					if ($current_user->validate()==true) {
						$template_loglist->set('user', $current_user->get_name());
					} else {
						$template_loglist->set('user', $language->get('USERS', 'CATEGORY_0'));
					}
				}
				$template_loglist->set('data', $current_log[$i]['data']);
				$log_entries = $log_entries.$template_loglist->get();
			}
			$template_log->set('log_entries', $log_entries);
			$template_main->set('page_content', $template_log->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='user_management') {
		if ($user->get_level() > 2) {
			$template_users = new template;
			$template_users->open('users.tpl');
			$template_users->set('user_hr', $language->get('STRING', 'USER_HR'));
			$template_users->set('users_disclaimer', $language->get('STRING', 'USER_DISCLAIMER'));
			$template_users->set('backup_db', $language->get('STRING', 'BACKUP'));
			$users = $user->get();
			$userlist = "";
			for($i = 0; $i < sizeof($users); $i = $i + 1) {
				$template_user = new template;
				$template_user->open('userlist.tpl');
				$template_user->set('name', "<a href='index.php?action=search_user&search_user=".$users[$i]['id']."'>".$users[$i]['name']."</a>");
				$template_user->set('email', $users[$i]['email']);
				$template_user->set('priviledge', $language->get('USERS', 'CATEGORY_'.$users[$i]['priviledges']));
				$template_user->set('registered', $language->get('STRING', 'REGISTERED'));
				$template_user->set('date', date($config->get('ENCODING', 'DATETIME'), strtotime($users[$i]['registered'])));
				$template_user->set('user_email', $language->get('STRING', 'USER_CONTACT'));
				$template_user->set('user_level_info', $language->get('STRING', 'LEVEL'));
				$template_user->set('user_delete', $language->get('STRING', 'USER_DELETE'));
				$template_user->set('user_manage', $language->get('STRING', 'USER_MANAGE'));
				$template_user->set('total_comments', $statistics->user_comments($users[$i]['id']));
				$template_user->set('comments_stored', $language->get('STRING', 'COMMENTS'));
				$template_user->set('total_reports', $statistics->user_reports($users[$i]['id']));
				$template_user->set('reports_stored', $language->get('STRING', 'REPORTS'));
				$template_user->set('total_likes', $statistics->user_likes($users[$i]['id']));
				$template_user->set('likes_stored', $language->get('STRING', 'LIKES'));
				$template_user->set('user_id', $users[$i]['id']);
				if ($users[$i]['priviledges'] == 0 )
					$template_user->set('status', $language->get('STRING', 'USER_DISABLED'));
				else
					$template_user->set('status', $language->get('STRING', 'USER_ENABLED'));
				$template_user->set('user_disable', $language->get('STRING', 'USER_DISABLE'));
				$template_user->set('user_id', $users[$i]['id']);
				for ($j=1; $j<$config->get('USERS', 'ROLES'); $j=$j+1) {
					$template_user->set('user_'.$j, $language->get('USERS', 'CATEGORY_'.$j));
					$template_user->set('user_role_'.$j, $j);
				}
				$userlist = $userlist.$template_user->get();
			}
			$template_users->set('user_list', $userlist);
			$template_main->set('page_content', $template_users->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='user_delete') {
		if ($user->get_level() > 2) {
			$user_id = '0';
			if (isset($_POST['user_id']))
				$user_id = $_POST['user_id'];
			else
				if (isset($_GET['user_id']))
					$user_id = $_GET['user_id'];
			$current_user = new user;
			$current_user->set_id($user_id);
			if ($current_user->exist($user_id)==true) {
				if ($current_user->get_level()==0) {
					$current_user->delete($user_id);
					$template_redirect = new template;
					$template_redirect->open('redirect.tpl');
					$template_redirect->set('url', "index.php?action=user_management");
					$template_main->set('page_content', $template_redirect->get());
				} else {
					$template_warning = new template;
					$template_warning->open('warning.tpl');
					$template_warning->set('title', $language->get('STRING', 'SORRY'));
					$template_warning->set('message', $language->get('STRING', 'USER_DELETE_ERROR'));
					$template_warning->set('actions', '');
					$template_main->set('page_content',  $template_warning->get());
				}
			} else {
				$template_redirect = new template;
				$template_redirect->open('redirect.tpl');
				$template_redirect->set('url', "index.php");
				$template_main->set('page_content', $template_redirect->get());
			}
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='user_management_priviledge') {
		if ($user->get_level() > 2) {
			$user_id = '0';
			if (isset($_POST['user_id']))
				$user_id = $_POST['user_id'];
			else
				if (isset($_GET['user_id']))
					$user_id = $_GET['user_id'];
			$priviledge = '0';
			if (isset($_POST['priviledge']))
				$priviledge = $_POST['priviledge'];
			else
				if (isset($_GET['priviledge']))
					$priviledge = $_GET['priviledge'];
			$user->priviledge($user_id, $priviledge);
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php?action=user_management");
			$template_main->set('page_content', $template_redirect->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='report_management') {
		if ($user->get_level() > 1) {
			$template_reports = new template;
			$template_reports->open('reports.tpl');
			$template_reports->set('reports', $language->get('STRING', 'REPORTS'));
			$template_reports->set('reports_pending', $language->get('STRING', 'REPORTS_PENDING'));
			$template_reports->set('reports_completed', $language->get('STRING', 'REPORTS_COMPLETED'));
			$template_reports->set('reports_disclaimer', $language->get('STRING', 'REPORTS_DISCLAIMER'));
			$template_reports->set('reports_pending_count', $reports->count_pending());
			$template_reports->set('reports_completed_count', $reports->count_completed());
			// Reports pending
			$reports_list_pending = "";
			$reports_list = $reports->get_pending();
			for($i = 0; $i < sizeof($reports_list); $i = $i + 1) {
				$template_report = new template;
				$template_report->open('comments.tpl');
				$current_poem = $reports_list[$i]['poem'];
				$current_poem = $poem->get($reports_list[$i]['poem']);
				$template_report->set('comment_data', "<ul>".nl2br($current_poem['data'])."</ul><ul>".$reports_list[$i]['data']."</ul>");
				$template_report->set('from_user', $language->get('STRING', 'USER_FROM'));
				$user_submitter = new user;
				$user_submitter->set_id($reports_list[$i]['user']);
				if ($user_submitter->validate()==true) {
					$template_report->set('user', "<a href='index.php?action=search_user&search_user=".$reports_list[$i]['user']."'>".$user_submitter->get_name()."</a>");
					$template_report->set('user_name', $user_submitter->get_name());
				} else {
					$template_report->set('user', $language->get('STRING', 'USER_GUEST'));
					$template_report->set('user_name', $language->get('STRING', 'USER_GUEST'));
				}
				$template_report->set('comment_date', date($config->get('ENCODING', 'DATETIME'), strtotime($reports_list[$i]['date'])));
				$template_comment_delete = new template;
				$template_comment_delete->open('conclude.tpl');
				$template_comment_delete->set('conclude', $language->get('STRING', 'CONCLUDE'));
				$template_comment_delete->set('report_id', $reports_list[$i]['id']);
				$template_report->set('comment_delete', $template_comment_delete->get());
				$reports_list_pending = $reports_list_pending.$template_report->get();
			}	
			$template_reports->set('reports_list_pending', $reports_list_pending);
			// Reports completed
			$reports_list_completed = "";
			$reports_list = $reports->get_completed();
			for($i = 0; $i < sizeof($reports_list); $i = $i + 1) {
				$template_report = new template;
				$template_report->open('comments.tpl');
				$current_poem = $reports_list[$i]['poem'];
				$current_poem = $poem->get($reports_list[$i]['poem']);
				$template_report->set('comment_data', "<ul>".nl2br($current_poem['data'])."</ul><ul>".$reports_list[$i]['data']."</ul>");
				$template_report->set('from_user', $language->get('STRING', 'USER_FROM'));
				$user_submitter = new user;
				$user_submitter->set_id($reports_list[$i]['user']);
				if ($user_submitter->validate()==true) {
					$template_report->set('user', "<a href='index.php?action=search_user&search_user=".$reports_list[$i]['user']."'>".$user_submitter->get_name()."</a>");
					$template_report->set('user_name', $user_submitter->get_name());
				} else {
					$template_report->set('user', $language->get('STRING', 'USER_GUEST'));
					$template_report->set('user_name', $language->get('STRING', 'USER_GUEST'));
				}
				$template_report->set('comment_date', date($config->get('ENCODING', 'DATETIME'), strtotime($reports_list[$i]['date'])));				
				$template_comment_delete = new template;
				$template_comment_delete->open('remove.tpl');
				$template_comment_delete->set('remove', $language->get('STRING', 'REMOVE'));
				$template_comment_delete->set('report_id', $reports_list[$i]['id']);
				$template_report->set('comment_delete', $template_comment_delete->get());
				$reports_list_completed = $reports_list_completed.$template_report->get();
			}
			$template_reports->set('reports_list_completed', $reports_list_completed);
			$template_main->set('page_content', $template_reports->get());
		} else {
			$template_redirect = new template;
			$template_redirect->open('redirect.tpl');
			$template_redirect->set('url', "index.php");
			$template_main->set('page_content', $template_redirect->get());
		}
	} else if ($action=='platform') {
		$template_platform = new template;
		$template_platform->open('platform.tpl');
		$template_platform->set('platform', $language->get('STRING', 'PLATFORM_NAME'));
		$template_platform->set('platform_name', $config->get('APPLICATION', 'PLATFORM'));
		$template_platform->set('title', $language->get('STRING', 'PLATFORM_ABOUT'));
		$template_platform->set('application_version', $language->get('STRING', 'VERSION'));
		$template_platform->set('version', $config->get('APPLICATION', 'VERSION'));
		$template_platform->set('platform_about', $language->get('STRING', 'PLATFORM_INTRO'));
		$template_platform->set('backup_database_size', $language->get('STRING', 'BACKUP_DATABASE_SIZE'));
		$database_size = $database->format_size($database->getinfo('database_size'));
		$template_platform->set('database_size', $database_size);
		$language_platform = new ini;
		$language_platform->open($config->get('ENCODING', 'PLATFORM'));
		$language_platform->read();
		$template_platform->set('disclaimer', $language_platform->get('STRING', 'DISCLAIMER'));
		$template_platform->set('platform_updates', $language->get('STRING', 'PLATFORM_UPDATES'));
		$versions = 1;
		while ($language_platform->exist('UPDATES', 'VERSION_'.$versions.'_TITLE'))
			$versions = $versions + 1;
		$versions = $versions - 1;
		$legal = '';
		for ($i = $versions; $i >= 1; $i = $i - 1) {
			$template_legal = new template;
			$template_legal->open('version.tpl');
			$template_legal->set('title', $language_platform->get('UPDATES', 'VERSION_'.$i.'_TITLE'));
			$template_legal->set('data', $language_platform->get('UPDATES', 'VERSION_'.$i.'_DATA'));
			$legal = $legal.$template_legal->get();
		}
		$template_platform->set('legal', $legal);
		$template_main->set('page_content', $template_platform->get());
	} else if ($action=='contact') {
		$template_contact = new template;
		$template_contact->open('contact.tpl');
		$template_contact->set('contact_us', $language->get('STRING', 'CONTACT_US'));
		$template_contact->set('contact_disclaimer', $language->get('STRING', 'CONTACT_DISCLAIMER'));
		$template_contact->set('contact_our_email', $config->get('APPLICATION','CONTACT'));
		$template_contact->set('contact_terms', $language->get('STRING', 'CONTACT_TERMS'));
		$template_contact->set('send', $language->get('STRING', 'SEND'));
		$template_contact->set('contact_message', $language->get('STRING', 'CONTACT_MESSAGE'));
		$template_contact->set('contact_email', $language->get('STRING', 'CONTACT_EMAIL'));
		$template_main->set('page_content', $template_contact->get());
	} else if ($action=='message') {
		$contact_message = '';
		if (isset($_POST['contact_message']))
			$contact_message = $_POST['contact_message'];
		else
			if (isset($_GET['contact_message']))
				$contact_message = $_GET['contact_message'];
		$terms = '';
		if (isset($_POST['terms']))
			$terms = $_POST['terms'];
		else
			if (isset($_GET['terms']))
				$terms = $_GET['contact_message'];
		$contact_email = '';
		if (isset($_POST['contact_email']))
			$contact_email = $_POST['contact_email'];
		else
			if (isset($_GET['contact_email']))
				$contact_email = $_GET['contact_email'];
		if($terms == 1) {
			if($contact_email != '') {
				$template_warning = new template;
				$template_warning->open('warning.tpl');
				$template_warning->set('title', $language->get('STRING', 'CONTACT_US'));
				$template_warning->set('message', $language->get('STRING', 'CONTACT_SENT_REPLY'). ' <strong>'.$contact_email.'</strong>!');
				$template_warning->set('actions', '');
				$template_main->set('page_content',  $template_warning->get());			
			} else {
				$template_warning = new template;
				$template_warning->open('warning.tpl');
				$template_warning->set('title', $language->get('STRING', 'CONTACT_US'));
				$template_warning->set('message', $language->get('STRING', 'CONTACT_SENT'));
				$template_warning->set('actions', '');
				$template_main->set('page_content',  $template_warning->get());
			}
			$mail_message = '';
			$template_email = new template;
			$template_email->open('email.tpl');
			$template_email->set('title', $config->get('APPLICATION', 'TITLE'));
			$template_email->set('url', $config->get('APPLICATION', 'URL'));
			$template_email->set('description', $config->get('APPLICATION', 'DESCRIPTION'));
			$template_email->set('action', $language->get('STRING', 'CONTACT_NEW'));
			$template_email->set('action_description', $language->get('STRING', 'CONTACT_NEW_HELP').' '.$contact_email);
			$template_email->set('action_data', nl2br($contact_message));
			$mail_message = $template_email->get();			
			$user->mail_utf8($config->get('APPLICATION','CONTACT'), $config->get('APPLICATION','TITLE'), $contact_email, $language->get('STRING', 'CONTACT_NEW'), $mail_message);
		} else {
			$template_warning = new template;
			$template_warning->open('warning.tpl');
			$template_warning->set('title', $language->get('STRING', 'CONTACT_US'));
			$template_warning->set('message', $language->get('STRING', 'CONTACT_TERMS_ACCEPT'));
			$template_warning->set('actions', '');
			$template_main->set('page_content',  $template_warning->get());
		}
	} else if ($action=='members') {
		$template_members = new template;
		$template_members->open('members.tpl');
		$template_members->set('members', $language->get('STRING', 'USER_MEMBERS'));
		$template_members->set('user', $language->get('STRING', 'USER'));
		$template_members->set('user_poems', $language->get('STRING', 'POEM_ADDED'));
		$template_members->set('members_disclaimer', $language->get('STRING', 'USER_MEMBERS_DISCLAIMER'));
		$users_all = $statistics->top_poem_users_all();
		$user_list = "";
		for ($i = 0; $i < sizeof($users_all); $i = $i + 1) {
			$template_memberlist = new template;
			$template_memberlist->open('memberlist.tpl');
			$user_submitter = new user;
			$user_submitter->set_id($users_all[$i]['id']);
			if ($user_submitter->validate()==true) {
				$template_memberlist->set('user_id', "<a href='index.php?action=search_user&search_user=".$users_all[$i]['id']."'>".$user_submitter->get_name()."</a>");
				$template_memberlist->set('user_count', $users_all[$i]['memberCount']);
				$user_list = $user_list.$template_memberlist->get();
			}
		}
		$template_members->set('memberlist', $user_list);
		$template_main->set('page_content', $template_members->get());		
	} else if ($action=='view') {
		$poem_id = '0';
		if (isset($_POST['poem']))
			$poem_id = $_POST['poem'];
		else
			if (isset($_GET['poem']))
				$poem_id = $_GET['poem'];
		$current_poem = $poem->get($poem_id);
		$template_poem = new template;
		$template_poem->open('poem.tpl');
		$template_poem->set('poem', nl2br($current_poem['data']));
		$template_poem->set('poem_id', $current_poem['id']);
		$template_poem->set('poem_order', $language->get('STRING', 'ORDER_LIST'));
		$template_poem->set('category', $language->get('STRING', 'CATEGORY'));
		$template_poem->set('poem_category', $language->get('POEM_CATEGORIES', 'CATEGORY_'.$current_poem['category']));
		$template_poem->set('poem_category_search', $current_poem['category']);
		$template_poem->set('origin', $language->get('STRING', 'ORIGIN'));				
		$template_poem->set('poem_origin', $language->get('POEM_ORIGINS', 'CATEGORY_'.$current_poem['owner']));
		$template_poem->set('poem_origin_search', $current_poem['owner']);
		$template_poem->set('added', $language->get('STRING', 'ADDED'));				
		$template_poem->set('poem_date', date($config->get('ENCODING', 'DATETIME'), strtotime($current_poem['date'])));
		$template_poem->set('user', $language->get('STRING', 'SUBMITTER'));
		$template_poem->set('poem_name', nl2br($current_poem['name']));
		$template_poem->set('poem_share', $language->get('STRING', 'SHARE'));
		if ($current_poem['user'] == 0) {
			$template_poem->set('user_info', $language->get('STRING', 'USER_GUEST'));
		} else {
			$user_submitter = new user;
			$user_submitter->set_id($current_poem['user']);
			if ($user_submitter->validate()==true) {
				$template_poem->set('user_info', "<a href='index.php?action=search_user&search_user=".$current_poem['user']."'>".$user_submitter->get_name()."</a>");
			} else {
				$template_poem->set('user_info', $language->get('STRING', 'USER_GUEST'));
			}
		}
		$template_poem->set('popularity', $language->get('STRING', 'POPULARITY'));
		$template_poem->set('poem_popularity', $current_poem['popularity']);				
		if ($current_poem['status'] > 0) {
			$template_poem->set('poem_status', '');				
			$template_poem->set('poem_status_pending', '');
		} else {
			$template_poem->set('poem_status', "<img src='assets/images/warning.png' style='vertical-align:middle;'>");				
			$template_poem->set('poem_status_pending', $language->get('STRING', 'POEM_DRAFT_PENDING'));	
		}
		// Share buttons
		// E-mail
			$template_mail = new template;
			$template_mail->open('mail.tpl');
			$template_mail->set('mail_share', $language->get('STRING', 'SHARE_EMAIL'));
			$template_mail->set('mail_subject', urlencode('touloum.gr'));
			$template_mail->set('mail_body', urlencode($current_poem['data']));
			$template_poem->set('mail_share', $template_mail->get());
		// Twitter
			$template_twitter = new template;
			$template_twitter->open('twitter.tpl');
			$actual_link = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$template_twitter->set('current_page', urlencode($actual_link));
			$template_twitter->set('current_poem', $current_poem['data']);
			$template_twitter->set('twitter_share', $language->get('STRING', 'SHARE_TWITTER'));
			$template_poem->set('twitter_share', $template_twitter->get());
		// SMS
			$template_sms = new template;
			$template_sms->open('sms.tpl');
			$template_sms->set('sms_share', $language->get('STRING', 'SHARE_SMS'));
			$template_sms->set('current_poem', $current_poem['data']);
			$template_poem->set('sms_share', $template_sms->get());
		// Viber
			$template_viber = new template;
			$template_viber->open('viber.tpl');
			$template_viber->set('viber_share', $language->get('STRING', 'SHARE_VIBER'));
			$template_viber->set('current_poem', $current_poem['data']);
			$template_poem->set('viber_share', $template_viber->get());
		// Facebook
			$template_facebook = new template;
			$template_facebook->open('facebook.tpl');
			$actual_link = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			$template_facebook->set('current_page', "title=touloum&quote=".urlencode($current_poem['data'])."&u=".urlencode($actual_link));
			$template_facebook->set('facebook_share', $language->get('STRING', 'SHARE_FACEBOOK'));
			$template_poem->set('facebook_share', $template_facebook->get());
		$template_like = new template;
		$template_like->open('like.tpl');
		$template_like->set('current_page', "index.php?action=like&poem=".$current_poem['id']);
		$template_like->set('like_it', $language->get('STRING', 'LIKE_IT'));				
		$template_poem->set('poem_like', $template_like->get());
		$template_poem->set('comments', $language->get('STRING', 'COMMENTS'));
		$template_poem->set('poem_comments', $comment->count($current_poem['id']));
		// Approval (form user level 2 or 3)
		if ($user->get_level() > 1) {
			if ($current_poem['status'] == 0) {
				$template_approve = new template;
				$template_approve->open('approve.tpl');
				$template_approve->set('approve', $language->get('STRING', 'APPROVE'));
				$template_approve->set('poem_id', $current_poem['id']);
				$template_poem->set('poem_approval', $template_approve->get());	
			} else {
				$template_approve = new template;
				$template_approve->open('disaprove.tpl');
				$template_approve->set('disapprove', $language->get('STRING', 'DISAPPROVE'));
				$template_approve->set('poem_id', $current_poem['id']);
				$template_poem->set('poem_approval', $template_approve->get());
			}
		} else {
			$template_poem->set('poem_approval', '');
		}
		// Edit (if owner or user level 2 or 3)
		if ($user->get_level() > 1 || $current_poem['user'] == $user->get_id()) {
			$template_edit = new template;
			$template_edit->open('edit.tpl');
			$template_edit->set('edit', $language->get('STRING', 'EDIT'));
			$template_edit->set('poem_id', $current_poem['id']);
			$template_poem->set('poem_edit', $template_edit->get());
		} else {
			$template_poem->set('poem_edit', '');
		}
		// Comments
		$template_poem->set('comments_results', $language->get('STRING', 'SEARCH_RESULTS')."<strong> ".$comment->count($current_poem['id'])."</strong> ".$language->get('STRING', 'COMMENTS_STORED'));
		$current_comments = $comment->search($current_poem['id']);
		$comments_list = "";
		for($i = 0; $i < sizeof($current_comments); $i = $i + 1) {
			$template_comment = new template;
			$template_comment->open('comments.tpl');
			$template_comment->set('comment_data', $current_comments[$i]['data']);
			$template_comment->set('from_user', $language->get('STRING', 'USER_FROM'));
			$user_submitter = new user;
			$user_submitter->set_id($current_comments[$i]['user']);
			if ($user_submitter->validate()==true) {
				$template_comment->set('user', "<a href='index.php?action=search_user&search_user=".$current_comments[$i]['user']."'>".$user_submitter->get_name()."</a>");
				$template_comment->set('user_name', $user_submitter->get_name());
			} else {
				$template_comment->set('user', $language->get('STRING', 'USER_GUEST'));
				$template_comment->set('user_name', $language->get('STRING', 'USER_GUEST'));
			}
			$template_comment->set('comment_date', date($config->get('ENCODING', 'DATETIME'), strtotime($current_comments[$i]['date'])));
			if ($user->get_level() > 1) {
				$template_comment_delete = new template;
				$template_comment_delete->open('delete.tpl');
				$template_comment_delete->set('remove', $language->get('STRING', 'REMOVE'));
				$template_comment_delete->set('comment_id', $current_comments[$i]['id']);
				$template_comment->set('comment_delete', $template_comment_delete->get());
			} else {
				$template_comment->set('comment_delete', '');
			}
			$comments_list = $comments_list.$template_comment->get();
		}
		$template_poem->set('comments_list', $comments_list);
		// Add comment for users only
		if ($user->get_level() > 0) {
			$template_comment_annotate = new template;
			$template_comment_annotate->open('annotate.tpl');
			$template_comment_annotate->set('comments_add', $language->get('STRING', 'COMMENTS_ADD'));
			$template_comment_annotate->set('comments_disclaimer', $language->get('STRING', 'COMMENTS_DISCLAIMER'));
			$template_comment_annotate->set('poem_id', $current_poem['id']);
			$template_comment_annotate->set('comment', $language->get('STRING', 'COMMENTS'));
			$template_comment_annotate->set('add', $language->get('STRING', 'ADD'));
			$template_poem->set('comments_annotate', $template_comment_annotate->get());
		} else {
			$template_poem->set('comments_annotate', '');
		}
		// Report
		$template_poem->set('report',  $language->get('STRING', 'REPORT'));
		$template_poem->set('report_disclaimer',  $language->get('STRING', 'REPORT_DISCLAIMER'));
		$template_poem->set('poem_id', $current_poem['id']);
		$template_poem->set('add',  $language->get('STRING', 'ADD'));
		$template_main->set('page_content',  $template_poem->get());
	} else {
		$template_home = new template;
		$template_home->open('home.tpl');
		$template_home->set('welcome',  $language->get('STRING', 'WELCOME_HOME'));
		$template_home->set('about',  $language->get('STRING', 'ABOUT'));
		$template_home->set('stat_new_poems',  $language->get('STRING', 'STAT_NEW_POEMS'));
		$template_home->set('stat_top_poems',  $language->get('STRING', 'STAT_TOP_POEMS'));
		$template_home->set('stat_top_poems_comments',  $language->get('STRING', 'STAT_TOP_POEMS_COMMENTS'));
		$template_home->set('stat_top_users',  $language->get('STRING', 'STAT_TOP_USERS'));
		$template_home->set('new_comments',  $language->get('STRING', 'COMMENTS_ADD'));
		// Load anouncement
		$announcement = new ini;
		$announcement->open($config->get('ENCODING', 'ANNOUNCEMENTS'));
		$announcement->read();
		if($announcement->get('ANNOUNCEMENT', 'TITLE')=='' && $announcement->get('ANNOUNCEMENT', 'DATA')=='') {
			$template_home->set('announcement',  '');
		} else {
			$template_announcement = new template;
			$template_announcement->open('announcement.tpl');
			$template_announcement->set('title',  $announcement->get('ANNOUNCEMENT', 'TITLE'));
			$template_announcement->set('data',  $announcement->get('ANNOUNCEMENT', 'DATA'));
			$template_home->set('announcement',  $template_announcement->get());
		}
		// Latest poems
		$latest_poems = $statistics->latest_poems();
		for ($i = 0; $i < 5; $i++) {
			if ($i < sizeof($latest_poems)) {
				$template_home->set('latest_poems_'.($i+1), nl2br($latest_poems[$i]['data']));
				$template_home->set('latest_poem_id_'.($i+1), nl2br($latest_poems[$i]['id']));
				$template_home->set('latest_poem_date_'.($i+1), date($config->get('ENCODING', 'DATETIME'), strtotime($latest_poems[$i]['date'])));
			} else {
				$template_home->set('latest_poems_'.($i+1), '&nbsp;');
				$template_home->set('latest_poem_id_'.($i+1), '&nbsp;');
				$template_home->set('latest_poem_date_'.($i+1), '&nbsp;');
			}
		}
		$top_poems = $statistics->top_poems();
		for ($i = 0; $i < 5; $i++) {
			if ($i < sizeof($top_poems)) {
				$template_home->set('top_poems_'.($i+1), nl2br($top_poems[$i]['data']));
				$template_home->set('top_poem_id_'.($i+1), nl2br($top_poems[$i]['id']));
				$template_home->set('top_poem_date_'.($i+1), $top_poems[$i]['popularity']);
			} else {
				$template_home->set('top_poems_'.($i+1), '&nbsp;');
				$template_home->set('top_poem_id_'.($i+1), '&nbsp;');
				$template_home->set('top_poem_date_'.($i+1), '&nbsp;');
			}
		}
		$top_poems = $statistics->top_poem_comments();
		for ($i = 0; $i < 5; $i = $i + 1) {
			if ($i < sizeof($top_poems)) {
				$current_poem = $poem->get($top_poems[$i]['id']);
				$template_home->set('comments_poems_'.($i+1), nl2br($current_poem['data']));
				$template_home->set('comments_poem_id_'.($i+1), nl2br($top_poems[$i]['id']));
				$template_home->set('comments_poem_date_'.($i+1), $top_poems[$i]['memberCount']);
			} else {
				$template_home->set('comments_poems_'.($i+1), '&nbsp;');
				$template_home->set('comments_poem_id_'.($i+1), '&nbsp;');
				$template_home->set('comments_poem_date_'.($i+1), '0');
			}
		}
		$top_users = $statistics->top_poem_users();
		for ($i = 0; $i < 5; $i = $i + 1) {
			if ($i < sizeof($top_users)) {
				$current_user = new user;
				$current_user->set_id($top_users[$i]['id']);
				if ($current_user->validate()==true) {
					$template_home->set('users_poems_'.($i+1), $current_user->get_name());
					$template_home->set('users_poem_id_'.($i+1), $current_user->get_id());
				} else {
					$template_home->set('users_poems_'.($i+1), '&nbsp;');
					$template_home->set('users_poem_id_'.($i+1), '&nbsp;');
				}
				$template_home->set('users_poem_date_'.($i+1), $top_users[$i]['memberCount']);
			} else {
				$template_home->set('users_poems_'.($i+1), '&nbsp;');
				$template_home->set('users_poem_id_'.($i+1), '&nbsp;');
				$template_home->set('users_poem_date_'.($i+1), '0');
			}
		}
		$template_home->set('poems',  $language->get('STRING', 'POEMS'));
		$latest_comments = $statistics->latest_comments();
		for ($i = 0; $i < 5; $i++) {
			if ($i < sizeof($latest_comments)) {
				$template_home->set('latest_comments_'.($i+1), nl2br($latest_comments[$i]['data']));
				$template_home->set('latest_comments_id_'.($i+1), nl2br($latest_comments[$i]['poem']));
				$template_home->set('latest_comments_date_'.($i+1), date($config->get('ENCODING', 'DATETIME'), strtotime($latest_comments[$i]['date'])));
			} else {
				$template_home->set('latest_comments_'.($i+1), '&nbsp;');
				$template_home->set('latest_comments_id_'.($i+1), '&nbsp;');
				$template_home->set('latest_comments_date_'.($i+1), '&nbsp;');
			}
		}
		// Statistics
		$template_home->set('stat_total_poems',  $language->get('STRING', 'STAT_TOTAL_POEMS'));
		$template_home->set('stat_total_poems_count',  ($poem->count_accepted() + $poem->count_drafts()));
		$template_home->set('stat_total_users',  $language->get('STRING', 'STAT_TOTAL_USERS'));
		$template_home->set('stat_total_users_count',  $user->count());
		$template_home->set('stat_total_comments',  $language->get('STRING', 'STAT_TOTAL_COMMENTS'));
		$template_home->set('stat_total_comments_count',  $comment->count_all());
		$template_home->set('stat_total_likes',  $language->get('STRING', 'STAT_TOTAL_LIKES'));
		$template_home->set('stat_total_likes_count',  $poem->count_popularity());
		$template_home->set('stat_intro',  $language->get('STRING', 'STAT_INTRO'));
		$template_home->set('and',  $language->get('STRING', 'AND'));
		$template_main->set('page_content',  $template_home->get());
	}
	// Update static page content
	$template_main->set('page_static', '');
	//
	//
	//
	//
	//
	//
	// Reserved for future extension (ads etc/)
	//
	//
	//
	//
	//
	//
	echo $template_main->get();
	function handle_search_results($search_results, $page, $action, $query) {
		Global $language;
		Global $config;
		Global $comment;
		$results = "";
		if (sizeof($search_results) > 1 ) {
			$results = $results.$language->get('STRING', 'SEARCH_RESULTS').'<strong> '.$search_results['count'].'</strong>'.$language->get('STRING', 'POEMS').' '.$language->get('STRING', 'FOR').' "'.$query.'". ';
			$results = $results.$language->get('STRING', 'SEARCH_RANGE').'<strong>'.($page*$config->get('POEMS', 'SEARCH_PAGINATION')+1).' - '.($page*$config->get('POEMS', 'SEARCH_PAGINATION')+sizeof($search_results)-1).' </strong>';
			for($i = 0; $i <= (sizeof($search_results) - 2); $i = $i + 1) {
				$template_results = new template;
				$template_results->open('results.tpl');
				$template_results->set('poem', nl2br($search_results[$i]['data']));
				$template_results->set('poem_name', nl2br($search_results[$i]['name']));
				// Count comments
				$template_results->set('comments', $language->get('STRING', 'COMMENTS'));
				$template_results->set('poem_comments', $comment->count($search_results[$i]['id']));
				// Like link
				$template_like = new template;
				$template_like->open('like.tpl');
				$template_like->set('current_page', "index.php?action=like&poem=".$search_results[$i]['id']);
				$template_like->set('like_it', $language->get('STRING', 'LIKE_IT'));				
				$template_results->set('poem_like', $template_like->get());
				$template_results->set('poem_share', $language->get('STRING', 'SHARE'));
				// Share links
				// Facebook
					$template_facebook = new template;
					$template_facebook->open('facebook.tpl');
					$actual_link = "http://www.touloum.gr/index.php?action=view&poem=".$search_results[$i]['id'];
					$template_facebook->set('current_page', "title=touloum&quote=".urlencode($search_results[$i]['data'])."&u=".urlencode($actual_link));
					$template_facebook->set('facebook_share', $language->get('STRING', 'SHARE_FACEBOOK'));
					$template_results->set('facebook_share', $template_facebook->get());
				// Twitter
					$template_twitter = new template;
					$template_twitter->open('twitter.tpl');
					$actual_link = "http://www.touloum.gr/index.php?action=view&poem=".$search_results[$i]['id'];
					$template_twitter->set('current_page', urlencode($actual_link));
					$template_twitter->set('current_poem', $search_results[$i]['data']);
					$template_twitter->set('twitter_share', $language->get('STRING', 'SHARE_TWITTER'));
					$template_results->set('twitter_share', $template_twitter->get());
				// E-mail
					$template_mail = new template;
					$template_mail->open('mail.tpl');
					$template_mail->set('mail_share', $language->get('STRING', 'SHARE_EMAIL'));
					$template_mail->set('mail_subject', urlencode('touloum.gr'));
					$template_mail->set('mail_body', urlencode($search_results[$i]['data']));
					$template_results->set('mail_share', $template_mail->get());
				// SMS
					$template_sms = new template;
					$template_sms->open('sms.tpl');
					$template_sms->set('sms_share', $language->get('STRING', 'SHARE_SMS'));
					$template_sms->set('current_poem', $search_results[$i]['data']);
					$template_results->set('sms_share', $template_sms->get());
				// Viber
					$template_viber = new template;
					$template_viber->open('viber.tpl');
					$template_viber->set('viber_share', $language->get('STRING', 'SHARE_VIBER'));
					$template_viber->set('current_poem', $search_results[$i]['data']);
					$template_results->set('viber_share', $template_viber->get());
				$template_results->set('poem_id', $search_results[$i]['id']);
				$template_results->set('category', $language->get('STRING', 'CATEGORY'));				
				$template_results->set('poem_category', $language->get('POEM_CATEGORIES', 'CATEGORY_'.$search_results[$i]['category']));
				$template_results->set('poem_category_search', $search_results[$i]['category']);
				$template_results->set('origin', $language->get('STRING', 'ORIGIN'));				
				$template_results->set('poem_origin', $language->get('POEM_ORIGINS', 'CATEGORY_'.$search_results[$i]['owner']));
				$template_results->set('poem_origin_search', $search_results[$i]['owner']);
				$template_results->set('added', $language->get('STRING', 'ADDED'));				
				$template_results->set('poem_date', date($config->get('ENCODING', 'DATETIME'), strtotime($search_results[$i]['date'])));
				$template_results->set('popularity', $language->get('STRING', 'POPULARITY'));
				$template_results->set('poem_popularity', $search_results[$i]['popularity']);
				$template_results->set('user', $language->get('STRING', 'SUBMITTER'));
				$template_results->set('poem_order', $language->get('STRING', 'ORDER_LIST'));
				if ($search_results[$i]['user'] == 0) {
					$template_results->set('user_info', $language->get('STRING', 'USER_GUEST'));
				} else {
					$user_submitter = new user;
					$user_submitter->set_id($search_results[$i]['user']);
					if ($user_submitter->validate()==true) {
						$template_results->set('user_info', "<a href='index.php?action=search_user&search_user=".$search_results[$i]['user']."'>".$user_submitter->get_name()."</a>");
					} else {
						$template_results->set('user_info', $language->get('STRING', 'USER_GUEST'));
					}
				}
				if ($search_results[$i]['status'] > 0) {
					$template_results->set('poem_status', '');				
					$template_results->set('poem_status_pending', '');
				} else {
					$template_results->set('poem_status', "<img src='assets/images/warning.png' style='vertical-align:middle;'>");				
					$template_results->set('poem_status_pending', $language->get('STRING', 'POEM_DRAFT_PENDING'));	
				}
				$results = $results.$template_results->get();
			}
			// Result pagination
			if ($page > 0) {
				$template_pagination = new template;
				$template_pagination->open('pagination.tpl');
				$template_pagination->set('action', $action);
				$template_pagination->set('page', ($page-1));
				$template_pagination->set('page_handler', $language->get('STRING', 'PREVIOUS'));
				$results = $results.$template_pagination->get();
			}
			for($i = 0; $i < $search_results['count']/$config->get('POEMS', 'SEARCH_PAGINATION'); $i = $i + $config->get('POEMS', 'SEARCH_PAGINATION_STEP')) {
				if ($i != $page) {
					$template_pagination = new template;
					$template_pagination->open('pagination.tpl');
					$template_pagination->set('action', $action);
					$template_pagination->set('page', $i);
					$template_pagination->set('page_handler', $i + 1);
					$results = $results.$template_pagination->get();
				} else {
					$template_pagination = new template;
					$template_pagination->open('pagination.tpl');
					$template_pagination->set('action', $action);
					$template_pagination->set('page', $i);
					$template_pagination->set('page_handler', "<h2><u>".($i + 1)."</u></h2>");
					$results = $results.$template_pagination->get();
				}
			}
			if (($page+1)*$config->get('POEMS', 'SEARCH_PAGINATION') <= $search_results['count']) {
				$template_pagination = new template;
				$template_pagination->open('pagination.tpl');
				$template_pagination->set('action', $action);
				$template_pagination->set('page', ($page+1));
				$template_pagination->set('page_handler', $language->get('STRING', 'NEXT'));
				$results = $results.$template_pagination->get();
			}
		} else {
			$results = $results.$language->get('STRING', 'NO_RESULTS').' "'.$query.'"...';
		}
		return $results;		
	}
?>
